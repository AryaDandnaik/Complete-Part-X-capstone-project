-- =============================================================================
-- RetailPulse Data Quality & Operations Analytics
-- SQL Query Library — Part 1 Academic Submission
-- Database: retailpulse.db  (SQLite)
-- Tables  : orders, customers, products
-- =============================================================================

-- ─────────────────────────────────────────────────────────────────────────────
-- Q1: Total revenue and order volume by product category
--     Demonstrates: GROUP BY, aggregate functions, ORDER BY
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    product_category,
    COUNT(order_id)            AS total_orders,
    ROUND(SUM(revenue), 2)     AS total_revenue,
    ROUND(AVG(revenue), 2)     AS avg_order_value,
    ROUND(AVG(discount_pct),2) AS avg_discount_pct
FROM orders
GROUP BY product_category
ORDER BY total_revenue DESC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q2: High-value individual orders (revenue > $500)
--     Demonstrates: WHERE, ORDER BY, LIMIT
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    order_id,
    customer_id,
    product_category,
    quantity,
    unit_price,
    discount_pct,
    revenue
FROM orders
WHERE revenue > 500
ORDER BY revenue DESC
LIMIT 20;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q3: Countries generating more than $5 000 total revenue
--     Demonstrates: GROUP BY, HAVING, ORDER BY
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    country,
    COUNT(order_id)        AS orders,
    ROUND(SUM(revenue), 2) AS total_revenue
FROM orders
GROUP BY country
HAVING total_revenue > 5000
ORDER BY total_revenue DESC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q4: Payment method usage and revenue contribution
--     Demonstrates: GROUP BY, multiple aggregates, ORDER BY
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    payment_method,
    COUNT(*)               AS num_transactions,
    ROUND(SUM(revenue),2)  AS total_revenue,
    ROUND(AVG(revenue),2)  AS avg_revenue
FROM orders
GROUP BY payment_method
ORDER BY num_transactions DESC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q5: Top 15 customers from USA or UK with per-order revenue > $200
--     Demonstrates: WHERE with AND / OR, GROUP BY, ORDER BY, LIMIT
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    customer_id,
    customer_name,
    country,
    gender,
    COUNT(order_id)          AS orders,
    ROUND(SUM(revenue), 2)   AS lifetime_value
FROM orders
WHERE (country = 'USA' OR country = 'UK')
  AND revenue > 200
GROUP BY customer_id
ORDER BY lifetime_value DESC
LIMIT 15;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q6: Monthly revenue trend (time-series aggregation)
--     Demonstrates: string function, GROUP BY, ORDER BY ASC
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    SUBSTR(order_date, 1, 7)   AS year_month,
    COUNT(order_id)            AS orders,
    ROUND(SUM(revenue), 2)     AS monthly_revenue
FROM orders
GROUP BY year_month
ORDER BY year_month ASC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q7: Unit price vs category benchmark (price deviation analysis)
--     Demonstrates: JOIN (orders ⟕ products)
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    o.order_id,
    o.product_category,
    o.unit_price,
    p.avg_unit_price           AS category_avg_price,
    ROUND(o.unit_price - p.avg_unit_price, 2) AS price_vs_avg
FROM orders o
JOIN products p ON o.product_category = p.product_category
ORDER BY ABS(price_vs_avg) DESC
LIMIT 20;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q8: Revenue breakdown by gender and product category
--     Demonstrates: multi-column GROUP BY, aggregate, ORDER BY
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    gender,
    product_category,
    COUNT(order_id)        AS orders,
    ROUND(SUM(revenue),2)  AS total_revenue
FROM orders
GROUP BY gender, product_category
ORDER BY gender, total_revenue DESC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q9: Discounted Electronics orders with quantity > 2  (business filter)
--     Demonstrates: WHERE with AND (multi-condition, category specific)
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    order_id,
    customer_id,
    quantity,
    unit_price,
    discount_pct,
    revenue
FROM orders
WHERE product_category = 'Electronics'
  AND discount_pct > 15
  AND quantity > 2
ORDER BY revenue DESC;


-- ─────────────────────────────────────────────────────────────────────────────
-- Q10: Average revenue per order — country × category cross-tab
--      Demonstrates: GROUP BY (two columns), HAVING, ORDER BY (business BI)
-- ─────────────────────────────────────────────────────────────────────────────
SELECT
    country,
    product_category,
    COUNT(order_id)       AS orders,
    ROUND(AVG(revenue),2) AS avg_order_revenue
FROM orders
GROUP BY country, product_category
HAVING orders >= 5
ORDER BY country, avg_order_revenue DESC;
