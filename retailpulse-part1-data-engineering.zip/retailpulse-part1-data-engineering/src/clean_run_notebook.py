"""
clean_run_notebook.py
=====================
Executes the notebook from a CLEAN environment:
  - Deletes previous output artefacts (PNGs, executed notebook, processed data)
  - Re-runs src/pipeline.py to regenerate raw data
  - Runs every cell in the notebook via nbformat + IPython kernel
  - Captures per-cell pass/fail with error details
  - Prints a final summary table
"""

import os
import sys
import json
import time
import shutil
import subprocess

BASE = r"c:\Users\HP\Desktop\capston project\retailpulse-part1-data-engineering"

# ---------------------------------------------------------------------------
# Step 0: Wipe artefacts so the notebook starts truly clean
# ---------------------------------------------------------------------------
print("=" * 65)
print("  STEP 0 — Clearing previous outputs for a clean run")
print("=" * 65)

# Delete old PNG charts
out_dir = os.path.join(BASE, "outputs")
if os.path.exists(out_dir):
    png_files = [f for f in os.listdir(out_dir) if f.endswith(".png")]
    for f in png_files:
        os.remove(os.path.join(out_dir, f))
    print(f"  Deleted {len(png_files)} PNG files from outputs/")

# Delete executed notebook
exec_nb = os.path.join(BASE, "notebooks", "01_data_engineering_eda_executed.ipynb")
if os.path.exists(exec_nb):
    os.remove(exec_nb)
    print("  Deleted previous executed notebook")

# Delete processed data
proc_dir = os.path.join(BASE, "data", "processed")
for fname in ["retailpulse_orders_clean.csv", "retailpulse.db"]:
    fpath = os.path.join(proc_dir, fname)
    if os.path.exists(fpath):
        os.remove(fpath)
        print(f"  Deleted {fname}")

# Delete raw data to force full re-generation
raw_csv = os.path.join(BASE, "data", "raw", "retailpulse_orders_raw.csv")
if os.path.exists(raw_csv):
    os.remove(raw_csv)
    print("  Deleted raw CSV (will regenerate)")

print("\n  Clean slate confirmed.\n")

# ---------------------------------------------------------------------------
# Step 1: Verify imports are available
# ---------------------------------------------------------------------------
print("=" * 65)
print("  STEP 1 — Verifying required packages")
print("=" * 65)
required = ["pandas", "numpy", "matplotlib", "seaborn", "sqlite3",
            "nbformat", "nbconvert", "ipykernel"]
missing = []
for pkg in required:
    try:
        __import__(pkg)
        print(f"  OK  {pkg}")
    except ImportError:
        print(f"  MISS  {pkg}")
        missing.append(pkg)

if missing:
    print(f"\n  Installing missing: {missing}")
    subprocess.run([sys.executable, "-m", "pip", "install"] + missing,
                   capture_output=True)
else:
    print("\n  All packages available.")

# ---------------------------------------------------------------------------
# Step 2: Execute notebook via nbconvert subprocess and parse output
# ---------------------------------------------------------------------------
print()
print("=" * 65)
print("  STEP 2 — Executing notebook (nbconvert, fresh kernel)")
print("=" * 65)

nb_src  = os.path.join(BASE, "notebooks", "01_data_engineering_eda.ipynb")
nb_out  = os.path.join(BASE, "notebooks", "01_data_engineering_eda_executed.ipynb")

t_start = time.time()

result = subprocess.run(
    [
        sys.executable, "-m", "nbconvert",
        "--to", "notebook",
        "--execute",
        "--ExecutePreprocessor.timeout=600",
        "--ExecutePreprocessor.kernel_name=python3",
        "--output", nb_out,
        nb_src,
    ],
    capture_output=True,
    text=True,
    cwd=os.path.join(BASE, "notebooks"),
)

elapsed = time.time() - t_start
print(f"\n  nbconvert exit code : {result.returncode}")
print(f"  Elapsed time        : {elapsed:.1f} s")

# Print stderr (contains progress + any errors)
if result.stderr:
    print("\n  --- nbconvert stderr ---")
    for line in result.stderr.strip().splitlines():
        print(f"  {line}")

if result.stdout:
    print("\n  --- nbconvert stdout ---")
    for line in result.stdout.strip().splitlines():
        print(f"  {line}")

# ---------------------------------------------------------------------------
# Step 3: Parse executed notebook for per-cell errors
# ---------------------------------------------------------------------------
print()
print("=" * 65)
print("  STEP 3 — Per-cell error scan")
print("=" * 65)

exec_ok = os.path.exists(nb_out)
cell_results = []

if exec_ok:
    with open(nb_out, encoding="utf-8") as f:
        nb_data = json.load(f)

    code_cells = [c for c in nb_data["cells"] if c["cell_type"] == "code"]
    print(f"  Code cells in executed notebook: {len(code_cells)}")
    print()

    for idx, cell in enumerate(code_cells, 1):
        source  = "".join(cell.get("source", []))[:80].replace("\n", " ")
        outputs = cell.get("outputs", [])

        has_error = any(o.get("output_type") == "error" for o in outputs)
        error_detail = ""
        if has_error:
            for o in outputs:
                if o.get("output_type") == "error":
                    ename = o.get("ename", "")
                    evalue = o.get("evalue", "")
                    tb_lines = o.get("traceback", [])
                    # Strip ANSI codes from traceback
                    import re
                    ansi = re.compile(r'\x1b\[[0-9;]*m')
                    tb_clean = [ansi.sub("", ln) for ln in tb_lines[-3:]]
                    error_detail = f"{ename}: {evalue}\n    " + "\n    ".join(tb_clean)

        has_output = len(outputs) > 0
        status = "ERROR" if has_error else ("OK" if has_output else "NO-OUT")
        cell_results.append((idx, status, source, error_detail))

        if has_error:
            print(f"  [{status}] Cell {idx:02d}: {source!r}")
            print(f"         {error_detail}")
            print()

    # Summary
    ok_count    = sum(1 for _, s, _, _ in cell_results if s == "OK")
    err_count   = sum(1 for _, s, _, _ in cell_results if s == "ERROR")
    noout_count = sum(1 for _, s, _, _ in cell_results if s == "NO-OUT")

    print(f"  Cells OK          : {ok_count}")
    print(f"  Cells with ERROR  : {err_count}")
    print(f"  Cells no output   : {noout_count}")
else:
    print("  ERROR: Executed notebook was NOT produced.")
    err_count = 999

# ---------------------------------------------------------------------------
# Step 4: Verify output artefacts
# ---------------------------------------------------------------------------
print()
print("=" * 65)
print("  STEP 4 — Artefact verification")
print("=" * 65)

checks = {
    "Raw CSV":      os.path.join(BASE, "data", "raw", "retailpulse_orders_raw.csv"),
    "Clean CSV":    os.path.join(BASE, "data", "processed", "retailpulse_orders_clean.csv"),
    "SQLite DB":    os.path.join(BASE, "data", "processed", "retailpulse.db"),
    "Executed NB":  nb_out,
}

for label, path in checks.items():
    exists = os.path.exists(path)
    size   = os.path.getsize(path) if exists else 0
    status = "OK" if exists and size > 100 else "MISSING"
    print(f"  [{status}]  {label}  ({size:,} bytes)")

pngs = [f for f in os.listdir(out_dir) if f.endswith(".png")] if os.path.exists(out_dir) else []
print(f"  [{'OK' if len(pngs) >= 7 else 'FAIL'}]  PNG charts  ({len(pngs)} files)")
for p in sorted(pngs):
    sz = os.path.getsize(os.path.join(out_dir, p))
    print(f"       {p}  ({sz:,} bytes)")

# ---------------------------------------------------------------------------
# Final verdict
# ---------------------------------------------------------------------------
print()
print("=" * 65)
print("  FINAL VERDICT")
print("=" * 65)
if exec_ok and err_count == 0 and len(pngs) >= 7:
    print("  RESULT : PASS")
    print("  The notebook ran to completion with ZERO cell errors.")
    print(f"  All {len(pngs)} charts were regenerated.")
    print(f"  All required data files were produced.")
else:
    print("  RESULT : FAIL")
    if not exec_ok:
        print("  Notebook execution did not produce output file.")
    if err_count > 0:
        print(f"  {err_count} cell(s) raised errors — see details above.")
    if len(pngs) < 7:
        print(f"  Only {len(pngs)} PNG charts produced (need >= 7).")
print("=" * 65)
