import json, os, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE = r"c:\Users\HP\Desktop\capston project\retailpulse-part1-data-engineering"
NB   = os.path.join(BASE, "notebooks", "01_data_engineering_eda.ipynb")
nb   = json.load(open(NB, encoding="utf-8"))

print("=== Markdown cells with cleaning decisions ===")
for i, cell in enumerate(nb["cells"]):
    if cell["cell_type"] == "markdown":
        src = "".join(cell["source"])
        if any(kw in src for kw in ["Clean","Drop","Fill","mode","median","decision","Rationale","Cleaning Rules"]):
            preview = src[:300].replace("\n", " | ")
            print(f"  Cell {i}: {preview}")
            print()

print()
print("=== Code cells documenting decisions ===")
for i, cell in enumerate(nb["cells"]):
    if cell["cell_type"] == "code":
        src = "".join(cell["source"])
        if any(kw in src for kw in ["FILL","DROP","Fill with","Drop column","Rationale","rationale","[OK]"]):
            preview = src[:200].replace("\n", " | ")
            print(f"  Cell {i}: {preview}")
            print()
