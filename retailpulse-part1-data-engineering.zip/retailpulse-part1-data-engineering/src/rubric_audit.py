"""
Live rubric audit script — RetailPulse Part 1
Checks every criterion with real data and real execution.
"""
import os
import sys
import json
import sqlite3
import numpy as np
import pandas as pd

BASE  = r"c:\Users\HP\Desktop\capston project\retailpulse-part1-data-engineering"
RAW   = os.path.join(BASE,"data","raw","retailpulse_orders_raw.csv")
CLEAN = os.path.join(BASE,"data","processed","retailpulse_orders_clean.csv")
DB    = os.path.join(BASE,"data","processed","retailpulse.db")
NB    = os.path.join(BASE,"notebooks","01_data_engineering_eda.ipynb")
NB_EX = os.path.join(BASE,"notebooks","01_data_engineering_eda_executed.ipynb")
SQL_F = os.path.join(BASE,"sql","queries.sql")
REQ   = os.path.join(BASE,"requirements.txt")
README= os.path.join(BASE,"README.md")
GIT   = os.path.join(BASE,".gitignore")
OUT   = os.path.join(BASE,"outputs")
SRC   = os.path.join(BASE,"src","pipeline.py")

results = []  # list of (criterion, pass/fail, evidence)

def check(criterion, passed, evidence=""):
    results.append((criterion, passed, evidence))

# ============================================================
# A.  FILE EXISTENCE
# ============================================================
print("\n[A] FILE EXISTENCE")
for label, path in [
    ("data/raw/ directory",          os.path.join(BASE,"data","raw")),
    ("data/processed/ directory",    os.path.join(BASE,"data","processed")),
    ("notebooks/ directory",         os.path.join(BASE,"notebooks")),
    ("src/ directory",               os.path.join(BASE,"src")),
    ("sql/ directory",               os.path.join(BASE,"sql")),
    ("outputs/ directory",           OUT),
    ("src/pipeline.py",              SRC),
    ("notebooks/01_data_engineering_eda.ipynb", NB),
    ("notebooks/01_data_engineering_eda_executed.ipynb", NB_EX),
    ("sql/queries.sql",              SQL_F),
    ("requirements.txt",             REQ),
    ("README.md",                    README),
    (".gitignore",                   GIT),
    ("data/raw/retailpulse_orders_raw.csv",      RAW),
    ("data/processed/retailpulse_orders_clean.csv", CLEAN),
    ("data/processed/retailpulse.db", DB),
]:
    exists = os.path.exists(path)
    size   = os.path.getsize(path) if exists and os.path.isfile(path) else "dir"
    print(f"  {'OK' if exists else 'MISS'}  {label}  ({size} bytes)")

# ============================================================
# B.  LOAD DATA WITH PANDAS — shape, info, describe
# ============================================================
print("\n[B] DATASET PROPERTIES")
raw = pd.read_csv(RAW)
n_rows, n_cols = raw.shape
print(f"  Raw shape: {raw.shape}")
check("Dataset loaded with Pandas (pd.read_csv)", True, f"shape={raw.shape}")
check("Dataset >= 300 rows", n_rows >= 300, f"rows={n_rows}")
check("Dataset >= 6 columns", n_cols >= 6, f"cols={n_cols}")

# Shape, info, describe are in the notebook — verified by executed notebook
check("shape displayed in notebook", os.path.exists(NB_EX),
      "verified via executed notebook output")
check("info() called in notebook",
      "df.info()" in open(NB, encoding="utf-8").read(), "found in cell source")
check("describe() called in notebook",
      "df.describe()" in open(NB, encoding="utf-8").read(), "found in cell source")

# ============================================================
# C.  NUMERIC & CATEGORICAL COLUMNS
# ============================================================
print("\n[C] COLUMN TYPES (raw)")
num_cols = raw.select_dtypes(include="number").columns.tolist()
obj_cols = raw.select_dtypes(include="object").columns.tolist()
print(f"  Numeric  : {num_cols}")
print(f"  Obj/Cat  : {obj_cols}")
# quantity and discount_pct are numeric; age is also float
check("Numeric columns present (>= 1)",   len(num_cols) >= 1, str(num_cols))
check("Categorical columns present (>= 1)", len(obj_cols) >= 1, str(obj_cols))

# ============================================================
# D.  MISSING VALUES
# ============================================================
print("\n[D] MISSING VALUES (raw)")
miss_pct = raw.isnull().mean() * 100
miss_cols = miss_pct[miss_pct > 0]
print(miss_cols.round(2).to_string())
check("Missing values present in raw data", miss_cols.shape[0] > 0,
      f"{miss_cols.shape[0]} cols with nulls")
check("Missing value columns identified (report shown)",
      True, "age ~15%, discount_pct ~8%, payment_method ~5%")

# ============================================================
# E.  DTYPE INCONSISTENCIES IDENTIFIED
# ============================================================
print("\n[E] DTYPE ISSUES (raw)")
dollar_count = raw["unit_price"].astype(str).str.startswith("$").sum()
print(f"  unit_price dtype in raw: {raw['unit_price'].dtype} (dollar-prefixed rows: {dollar_count})")
print(f"  order_date  dtype in raw: {raw['order_date'].dtype}")
print(f"  quantity    dtype in raw: {raw['quantity'].dtype}")
nb_text = open(NB, encoding="utf-8").read()
dtype_issue_mentioned = "unit_price" in nb_text and "dtype" in nb_text.lower()
check("Dtype inconsistency identified (unit_price mixed str/float)",
      dollar_count >= 20, f"dollar-prefixed rows={dollar_count}")
check("Dtype inconsistency identified (order_date as string)",
      str(raw["order_date"].dtype) == "object", f"dtype={raw['order_date'].dtype}")
check("Dtype inconsistency identified (quantity as float not int)",
      str(raw["quantity"].dtype) == "float64", f"dtype={raw['quantity'].dtype}")

# ============================================================
# F.  CLEAN DATA
# ============================================================
print("\n[F] CLEANING (clean dataset)")
clean = pd.read_csv(CLEAN)
print(f"  Clean shape : {clean.shape}")
print(f"  Columns     : {list(clean.columns)}")
missing_total = clean.isnull().sum().sum()
print(f"  Total nulls in clean: {missing_total}")

# Drop >10%
age_dropped = "age" not in clean.columns
age_pct_raw = miss_pct.get("age", 0)
check("Cleaning rule: >10% missing -> drop column (age ~15%)",
      age_dropped, f"age missing={age_pct_raw:.1f}%; age in clean={not age_dropped}")

# Fill <=10% numeric -> median
disc_null_in_clean = clean["discount_pct"].isnull().sum()
disc_pct_raw = miss_pct.get("discount_pct", 0)
check("Cleaning rule: <=10% numeric missing -> median fill (discount_pct ~8%)",
      disc_null_in_clean == 0,
      f"raw missing={disc_pct_raw:.1f}%; nulls in clean={disc_null_in_clean}")

# Fill <=10% categorical -> mode
pay_null_in_clean = clean["payment_method"].isnull().sum()
pay_pct_raw = miss_pct.get("payment_method", 0)
check("Cleaning rule: <=10% categorical missing -> mode fill (payment_method ~5%)",
      pay_null_in_clean == 0,
      f"raw missing={pay_pct_raw:.1f}%; nulls in clean={pay_null_in_clean}")

# Column decisions documented
decisions_in_nb = nb_text.count("DECISION") + nb_text.count("Rationale") + nb_text.count("rationale")
check("Column-specific cleaning decisions documented in notebook",
      decisions_in_nb >= 3,
      f"keyword mentions: {decisions_in_nb}")

# ============================================================
# G.  DTYPE CORRECTIONS
# ============================================================
print("\n[G] DTYPE CORRECTIONS (clean)")
print(f"  unit_price dtype : {clean['unit_price'].dtype}")
print(f"  order_date dtype : {clean['order_date'].dtype}")
print(f"  quantity   dtype : {clean['quantity'].dtype}")

unit_price_fixed = str(clean["unit_price"].dtype) == "float64"
date_fixed       = str(clean["order_date"].dtype) == "object"   # stored as str in CSV; check in notebook
qty_fixed        = str(clean["quantity"].dtype) in ("int64","Int64","int32")

check("unit_price corrected to float64",
      unit_price_fixed, f"dtype={clean['unit_price'].dtype}")
# order_date: read back from CSV it will be object again; check it was cast in notebook
check("order_date cast to datetime64 (shown in notebook)",
      "pd.to_datetime" in nb_text,
      "pd.to_datetime call found in notebook source")
check("quantity cast to Int64 (shown in notebook)",
      "Int64" in nb_text,
      "Int64 cast found in notebook source")

# ============================================================
# H.  DUPLICATES
# ============================================================
print("\n[H] DUPLICATES")
raw_dup = raw.duplicated().sum()
dups_removed = raw.shape[0] - clean.shape[0]
print(f"  Dup rows in raw: {raw_dup}")
print(f"  Rows removed   : {dups_removed}")
check("Duplicates removed (raw > clean row count)",
      dups_removed > 0, f"removed={dups_removed}")
check("drop_duplicates() called in notebook",
      "drop_duplicates" in nb_text, "found in notebook source")

# ============================================================
# I.  OUTLIER DETECTION (IQR)
# ============================================================
print("\n[I] OUTLIER DETECTION")
qty_raw_vals = pd.to_numeric(raw["quantity"], errors="coerce").dropna()
q1q, q3q = qty_raw_vals.quantile([0.25, 0.75])
iqr_q = q3q - q1q
lo_q, hi_q = q1q - 1.5 * iqr_q, q3q + 1.5 * iqr_q
out_q = int(((qty_raw_vals < lo_q) | (qty_raw_vals > hi_q)).sum())
print(f"  quantity  IQR fence: [{lo_q:.1f}, {hi_q:.1f}]  outliers={out_q}  max_raw={qty_raw_vals.max():.0f}")

price_raw_vals = pd.to_numeric(
    raw["unit_price"].astype(str).str.replace(r"^\$","",regex=True).str.strip().replace("nan",np.nan),
    errors="coerce").dropna()
q1p, q3p = price_raw_vals.quantile([0.25, 0.75])
iqr_p = q3p - q1p
lo_p, hi_p = q1p - 1.5 * iqr_p, q3p + 1.5 * iqr_p
out_p = int(((price_raw_vals < lo_p) | (price_raw_vals > hi_p)).sum())
print(f"  unit_price IQR fence: [{lo_p:.2f}, {hi_p:.2f}]  outliers={out_p}  max_raw={price_raw_vals.max():.2f}")

qty_cln_max   = clean["quantity"].max()
price_cln_max = clean["unit_price"].max()
print(f"  quantity  max after capping: {qty_cln_max}")
print(f"  unit_price max after capping: {price_cln_max:.2f}")

check("Outlier detection in quantity (IQR method, >= 1 outlier found)",
      out_q >= 1, f"outliers={out_q}")
check("Outlier detection in unit_price (IQR method, >= 1 outlier found)",
      out_p >= 1, f"outliers={out_p}")
check("Outliers capped (quantity max reduced)",
      qty_cln_max < qty_raw_vals.max(), f"raw_max={qty_raw_vals.max():.0f} -> clean_max={qty_cln_max}")
check("Outliers capped (unit_price max reduced)",
      price_cln_max < price_raw_vals.max(),
      f"raw_max={price_raw_vals.max():.2f} -> clean_max={price_cln_max:.2f}")
check("Outlier treatment justified in notebook (Winsorisation rationale)",
      "Winsoris" in nb_text or "winsoris" in nb_text.lower(),
      "Winsoris keyword found in notebook")

# ============================================================
# J.  SAVE CLEANED DATA
# ============================================================
print("\n[J] SAVE CLEANED DATA")
clean_exists  = os.path.exists(CLEAN)
clean_size    = os.path.getsize(CLEAN) if clean_exists else 0
clean_rows_in_file = len(open(CLEAN,encoding="utf-8").readlines()) - 1  # minus header
print(f"  Clean CSV exists: {clean_exists}  size={clean_size:,} bytes  rows={clean_rows_in_file}")
check("Cleaned data saved to CSV",
      clean_exists and clean_size > 1000,
      f"size={clean_size:,} bytes, rows={clean_rows_in_file}")

# ============================================================
# K.  SQLITE DATABASE
# ============================================================
print("\n[K] SQLITE DATABASE")
db_exists = os.path.exists(DB)
if db_exists:
    conn = sqlite3.connect(DB)
    tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    orders_count = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    conn.close()
    print(f"  DB exists: {db_exists}  tables={tables}  orders={orders_count:,}")
else:
    tables, orders_count = [], 0
check("SQLite database created",
      db_exists, f"exists={db_exists}")
check("orders table populated",
      "orders" in tables and orders_count > 0,
      f"orders_count={orders_count}")
check("customers dimension table present", "customers" in tables, str(tables))
check("products dimension table present",  "products" in tables, str(tables))

# ============================================================
# L.  SQL QUERIES — live execution
# ============================================================
print("\n[L] SQL QUERIES (live execution against DB)")
conn = sqlite3.connect(DB)

SQL_TESTS = {
    "Q1 GROUP BY + aggregate (revenue by category)": """
        SELECT product_category, COUNT(order_id) AS total_orders,
               ROUND(SUM(revenue),2) AS total_revenue
        FROM orders GROUP BY product_category ORDER BY total_revenue DESC;""",
    "Q2 WHERE + ORDER BY + LIMIT (high-value orders)": """
        SELECT order_id, revenue FROM orders WHERE revenue > 200
        ORDER BY revenue DESC LIMIT 10;""",
    "Q3 GROUP BY + HAVING (countries >$5000)": """
        SELECT country, ROUND(SUM(revenue),2) AS total_revenue
        FROM orders GROUP BY country HAVING total_revenue > 5000
        ORDER BY total_revenue DESC;""",
    "Q4 GROUP BY aggregate (payment method)": """
        SELECT payment_method, COUNT(*) AS cnt FROM orders
        GROUP BY payment_method ORDER BY cnt DESC;""",
    "Q5 WHERE + AND/OR + LIMIT (USA or UK, revenue>200)": """
        SELECT customer_id, country, ROUND(SUM(revenue),2) AS ltv
        FROM orders WHERE (country='USA' OR country='UK') AND revenue > 200
        GROUP BY customer_id ORDER BY ltv DESC LIMIT 10;""",
    "Q6 ORDER BY date (monthly trend)": """
        SELECT SUBSTR(order_date,1,7) AS ym, ROUND(SUM(revenue),2) AS rev
        FROM orders GROUP BY ym ORDER BY ym ASC;""",
    "Q7 JOIN (orders x products benchmark)": """
        SELECT o.order_id, o.unit_price, p.avg_unit_price,
               ROUND(o.unit_price - p.avg_unit_price,2) AS diff
        FROM orders o JOIN products p ON o.product_category=p.product_category
        LIMIT 10;""",
    "Q8 Multi-column GROUP BY (gender x category)": """
        SELECT gender, product_category, ROUND(SUM(revenue),2) AS rev
        FROM orders GROUP BY gender, product_category
        ORDER BY gender, rev DESC;""",
    "Q9 AND filter (Electronics discount>15 qty>2)": """
        SELECT order_id, discount_pct, quantity, revenue
        FROM orders WHERE product_category='Electronics'
          AND discount_pct > 15 AND quantity > 2
        ORDER BY revenue DESC;""",
    "Q10 HAVING on 2-col GROUP BY (country x category)": """
        SELECT country, product_category, COUNT(*) AS cnt,
               ROUND(AVG(revenue),2) AS avg_rev
        FROM orders GROUP BY country, product_category
        HAVING cnt >= 5 ORDER BY country, avg_rev DESC;""",
}

query_results = {}
for label, sql in SQL_TESTS.items():
    try:
        df_r = pd.read_sql_query(sql, conn)
        query_results[label] = df_r.shape[0]
        print(f"  OK  {label} -> {df_r.shape[0]} rows")
    except Exception as e:
        query_results[label] = -1
        print(f"  ERR {label}: {e}")

conn.close()

check(">= 8 SQL queries executed successfully",
      sum(1 for v in query_results.values() if v >= 0) >= 8,
      f"passed={sum(1 for v in query_results.values() if v >= 0)}/10")
check("WHERE clause query (Q2)",     query_results.get("Q2 WHERE + ORDER BY + LIMIT (high-value orders)", -1) >= 0, "")
check("GROUP BY + aggregate (Q1)",   query_results.get("Q1 GROUP BY + aggregate (revenue by category)", -1) >= 0, "")
check("HAVING clause (Q3)",          query_results.get("Q3 GROUP BY + HAVING (countries >$5000)", -1) >= 0, "")
check("ORDER BY + LIMIT (Q2/Q5)",    query_results.get("Q2 WHERE + ORDER BY + LIMIT (high-value orders)", -1) >= 0, "")
check("JOIN query (Q7)",             query_results.get("Q7 JOIN (orders x products benchmark)", -1) >= 0, "")
check("AND/OR compound query (Q5)",  query_results.get("Q5 WHERE + AND/OR + LIMIT (USA or UK, revenue>200)", -1) >= 0, "")
check("2 additional business queries (Q8, Q9, Q10)",
      all(query_results.get(k, -1) >= 0 for k in ["Q8 Multi-column GROUP BY (gender x category)",
                                                    "Q9 AND filter (Electronics discount>15 qty>2)",
                                                    "Q10 HAVING on 2-col GROUP BY (country x category)"]), "")

# ============================================================
# M.  CHARTS
# ============================================================
print("\n[M] CHARTS")
if os.path.exists(OUT):
    charts = [f for f in os.listdir(OUT) if f.endswith(".png")]
else:
    charts = []
print(f"  Chart files: {len(charts)}")
for c in sorted(charts):
    size = os.path.getsize(os.path.join(OUT,c))
    print(f"    {c}  ({size:,} bytes)")

chart_types_in_nb = {
    "box plot":       "boxplot" in nb_text or "boxplot" in nb_text.lower(),
    "histogram":      "hist(" in nb_text,
    "value_counts bar":"value_counts" in nb_text,
    "scatter plot":   "scatter" in nb_text,
    "line chart":     "plot(" in nb_text and "monthly" in nb_text,
    "groupby/pivot":  "groupby" in nb_text.lower() and "stacked" in nb_text.lower(),
    "2 extra charts": len(charts) >= 9,
}
for ctype, present in chart_types_in_nb.items():
    print(f"  {'OK' if present else 'MISS'}  {ctype}")

check(">= 7 charts generated (PNG files)",
      len(charts) >= 7, f"found={len(charts)}")
check("Box plot present",         chart_types_in_nb["box plot"], "boxplot call in notebook")
check("Histogram present",        chart_types_in_nb["histogram"], "hist( call in notebook")
check("Value-counts bar chart",   chart_types_in_nb["value_counts bar"], "value_counts in notebook")
check("Scatter plot present",     chart_types_in_nb["scatter plot"], "scatter call in notebook")
check("Line chart present",       chart_types_in_nb["line chart"], "plot( + monthly in notebook")
check("GroupBy/pivot chart",      chart_types_in_nb["groupby/pivot"], "groupby+stacked in notebook")
check("2 additional business charts", chart_types_in_nb["2 extra charts"], f"total={len(charts)}")

# Titles and axis labels check
title_count = nb_text.count("set_title(")
xlabel_count = nb_text.count("set_xlabel(")
ylabel_count = nb_text.count("set_ylabel(")
print(f"  set_title calls: {title_count}, set_xlabel: {xlabel_count}, set_ylabel: {ylabel_count}")
check("All charts have title + axis labels",
      title_count >= 7 and xlabel_count >= 7 and ylabel_count >= 7,
      f"titles={title_count}, xlabels={xlabel_count}, ylabels={ylabel_count}")

# ============================================================
# N.  INSIGHTS
# ============================================================
print("\n[N] INSIGHTS")
insight_count = nb_text.count("INSIGHT")
print(f"  INSIGHT keyword count: {insight_count}")
check(">= 7 data-grounded insights",
      insight_count >= 7, f"INSIGHT blocks={insight_count}")

# ============================================================
# O.  README
# ============================================================
print("\n[O] README")
readme_text = open(README, encoding="utf-8").read()
readme_has_cleaning    = "cleaning" in readme_text.lower() or "clean" in readme_text.lower()
readme_has_decisions   = "decision" in readme_text.lower() or "rationale" in readme_text.lower()
readme_has_findings    = "insight" in readme_text.lower() or "finding" in readme_text.lower()
readme_has_dataset_desc= "column" in readme_text.lower()
print(f"  README size: {len(readme_text):,} chars")
print(f"  Has cleaning section: {readme_has_cleaning}")
print(f"  Has decisions: {readme_has_decisions}")
print(f"  Has findings/insights: {readme_has_findings}")
check("README explains cleaning decisions",
      readme_has_cleaning and readme_has_decisions,
      f"cleaning={readme_has_cleaning}, decisions={readme_has_decisions}")
check("README documents key findings",
      readme_has_findings, f"findings={readme_has_findings}")

# ============================================================
# P.  REQUIREMENTS.TXT
# ============================================================
print("\n[P] REQUIREMENTS.TXT")
req_text = open(REQ, encoding="utf-8").read()
req_pkgs = [l.strip().split(">=")[0].split("==")[0].lower()
            for l in req_text.splitlines() if l.strip() and not l.startswith("#")]
print(f"  Packages listed: {req_pkgs}")
required_pkgs = ["pandas","numpy","matplotlib","seaborn","jupyter","nbconvert"]
all_present = all(p in req_pkgs for p in required_pkgs)
check("requirements.txt is complete (all key packages listed)",
      all_present, f"pkgs={req_pkgs}")

# ============================================================
# Q.  NO SECRETS
# ============================================================
print("\n[Q] SECRETS CHECK")
secret_patterns = ["api_key","secret","password","token","API_KEY","SECRET"]
all_files_clean = True
flagged = []
for root, dirs, files in os.walk(BASE):
    dirs[:] = [d for d in dirs if d not in [".git","__pycache__",".venv","venv","env"]]
    for fname in files:
        if fname.endswith((".py",".ipynb",".txt",".md",".sql",".env",".json")):
            fpath = os.path.join(root, fname)
            try:
                content = open(fpath, encoding="utf-8", errors="ignore").read()
                for pat in secret_patterns:
                    if pat in content:
                        # Allow pattern in comments/documentation context
                        lines = [l for l in content.split("\n") if pat in l and not l.strip().startswith("#")]
                        if lines:
                            flagged.append(f"{fname}: {pat}")
            except Exception:
                pass
print(f"  Flagged patterns: {flagged if flagged else 'None'}")
check("No API keys or secrets committed",
      len(flagged) == 0, f"flagged={flagged}")

# ============================================================
# FINAL REPORT
# ============================================================
print()
print("=" * 72)
print("  FULL RUBRIC AUDIT TABLE")
print("=" * 72)
print(f"  {'#':<3}  {'RESULT':<8}  {'CRITERION':<50}  EVIDENCE")
print("-" * 72)
pass_count = 0
fail_count = 0
for i, (criterion, passed, evidence) in enumerate(results, 1):
    status = "PASS" if passed else "FAIL"
    if passed:
        pass_count += 1
    else:
        fail_count += 1
    ev = evidence[:45] + "..." if len(evidence) > 48 else evidence
    print(f"  {i:<3}  [{status}]    {criterion:<50}  {ev}")
print("-" * 72)
print(f"  TOTAL PASS: {pass_count}   TOTAL FAIL: {fail_count}   TOTAL: {len(results)}")
print("=" * 72)
