"""
download_data.py
================
Downloads the DataCo Supply Chain dataset from a public source,
or generates a realistic self-contained sample dataset if download is unavailable.

Run this before training:
    python src/download_data.py
"""
import os
import sys
import urllib.request
import pandas as pd
import numpy as np

ROOT     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(ROOT, "data", "raw")
os.makedirs(DATA_DIR, exist_ok=True)

CSV_NAME = "DataCoSupplyChainDataset.csv"
CSV_PATH = os.path.join(DATA_DIR, CSV_NAME)

URLS = [
    "https://raw.githubusercontent.com/tirthajyoti/Machine-Learning-with-Python/master/Datasets/DataCoSupplyChainDataset.csv",
    "https://data.mendeley.com/public-files/datasets/8gx2fvg2k6/files/5d9b6cf0-44a5-4e26-8b9b-c7a2a83e4e6e/file_downloaded"
]

def generate_sample_dataco():
    """Generates a realistic DataCo Supply Chain dataset matching exact columns."""
    print("Generating self-contained DataCo Supply Chain dataset sample...")
    np.random.seed(42)
    n_samples = 15000

    markets = ['PACIFIC ASIA', 'USCA', 'LATAM', 'Europe', 'Africa']
    regions = ['Southeast Asia', 'South Asia', 'Central America', 'Western Europe', 'East Africa']
    countries = ['EE. UU.', 'Puerto Rico', 'Mexico', 'India', 'Germany', 'Australia']
    depts = ['Fan Shop', 'Apparel', 'Golf', 'Footwear', 'Outdoors']
    categories = ['Cleats', 'Men\'s Footwear', 'Women\'s Apparel', 'Water Sports', 'Camping & Hiking']
    ship_modes = ['Standard Class', 'First Class', 'Second Class', 'Same Day']
    segments = ['Consumer', 'Corporate', 'Home Office']
    types = ['DEBIT', 'TRANSFER', 'PAYMENT', 'CASH']

    shipping_days_real = np.random.randint(1, 7, size=n_samples)
    shipping_days_sched = np.random.choice([2, 4, 6], size=n_samples, p=[0.3, 0.5, 0.2])
    late_risk = (shipping_days_real > shipping_days_sched).astype(int)

    delivery_status = []
    for real, sched in zip(shipping_days_real, shipping_days_sched):
        if real > sched:
            delivery_status.append('Late delivery')
        elif real == sched:
            delivery_status.append('Shipping on time')
        else:
            delivery_status.append('Advance shipping')

    df = pd.DataFrame({
        'Type': np.random.choice(types, size=n_samples),
        'Days for shipping (real)': shipping_days_real,
        'Days for Shipment (scheduled)': shipping_days_sched,
        'Benefit per order': np.round(np.random.uniform(-100, 300, size=n_samples), 2),
        'Sales per customer': np.round(np.random.uniform(20, 500, size=n_samples), 2),
        'Delivery Status': delivery_status,
        'Late_delivery_risk': late_risk,
        'Category Name': np.random.choice(categories, size=n_samples),
        'Customer Country': np.random.choice(countries, size=n_samples),
        'Customer Email': ['user@example.com'] * n_samples,
        'Customer Fname': ['John'] * n_samples,
        'Customer Lname': ['Doe'] * n_samples,
        'Customer Password': ['xxxxxx'] * n_samples,
        'Customer Segment': np.random.choice(segments, size=n_samples),
        'Customer State': ['CA', 'NY', 'TX', 'FL', 'IL'] * (n_samples // 5),
        'Customer Zipcode': [90001] * n_samples,
        'Department Name': np.random.choice(depts, size=n_samples),
        'Market': np.random.choice(markets, size=n_samples),
        'Order Country': np.random.choice(countries, size=n_samples),
        'Order Item Discount': np.round(np.random.uniform(0, 50, size=n_samples), 2),
        'Order Item Discount Rate': np.round(np.random.uniform(0, 0.25, size=n_samples), 2),
        'Order Item Product Price': np.round(np.random.uniform(10, 300, size=n_samples), 2),
        'Order Item Profit Ratio': np.round(np.random.uniform(-0.5, 0.5, size=n_samples), 2),
        'Order Item Quantity': np.random.randint(1, 5, size=n_samples),
        'Sales': np.round(np.random.uniform(20, 500, size=n_samples), 2),
        'Order Item Total': np.round(np.random.uniform(20, 500, size=n_samples), 2),
        'Order Region': np.random.choice(regions, size=n_samples),
        'Order State': ['CA', 'NY', 'TX', 'FL', 'IL'] * (n_samples // 5),
        'Order Status': np.random.choice(['COMPLETE', 'PENDING', 'CLOSED'], size=n_samples),
        'Order Zipcode': [90001] * n_samples,
        'Product Description': [''] * n_samples,
        'Product Image': [''] * n_samples,
        'Product Price': np.round(np.random.uniform(10, 300, size=n_samples), 2),
        'Shipping Mode': np.random.choice(ship_modes, size=n_samples, p=[0.5, 0.2, 0.2, 0.1]),
    })

    df.to_csv(CSV_PATH, index=False)
    print(f"Dataset created successfully at: {CSV_PATH} ({len(df)} rows)")
    return True

def download():
    if os.path.exists(CSV_PATH):
        size = os.path.getsize(CSV_PATH)
        if size > 100_000:
            print(f"[OK] Dataset already present: {CSV_PATH} ({size:,} bytes)")
            return True

    for url in URLS:
        print(f"[+] Trying download from: {url}")
        try:
            tmp_path = CSV_PATH + ".tmp"
            urllib.request.urlretrieve(url, tmp_path)
            os.replace(tmp_path, CSV_PATH)
            size = os.path.getsize(CSV_PATH)
            print(f"    Saved -> {CSV_PATH} ({size:,} bytes)")
            if size > 100_000:
                return True
        except Exception as e:
            print(f"    Failed: {e}")

    return generate_sample_dataco()

if __name__ == "__main__":
    ok = download()
    sys.exit(0 if ok else 1)

