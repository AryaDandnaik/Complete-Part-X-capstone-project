"""
RetailPulse Command Center — app.py
Streamlit dashboard with interactive filters, KPI cards, Plotly charts,
a filtered dataframe, and live weather data via Open-Meteo API.

Run: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import os
from datetime import datetime

# ─────────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RetailPulse Command Center",
    page_icon="🛒",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────
# CUSTOM CSS — premium dark theme
# ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

  html, body, [class*="css"] {
      font-family: 'Inter', sans-serif;
  }

  /* Page background */
  .stApp {
      background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
      min-height: 100vh;
  }

  /* Sidebar */
  [data-testid="stSidebar"] {
      background: rgba(255,255,255,0.05);
      border-right: 1px solid rgba(255,255,255,0.1);
      backdrop-filter: blur(10px);
  }

  /* KPI card */
  .kpi-card {
      background: rgba(255,255,255,0.07);
      border: 1px solid rgba(255,255,255,0.15);
      border-radius: 16px;
      padding: 24px 20px;
      text-align: center;
      backdrop-filter: blur(10px);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
  }
  .kpi-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 40px rgba(102,126,234,0.3);
  }
  .kpi-label {
      color: rgba(255,255,255,0.6);
      font-size: 0.78rem;
      font-weight: 500;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 8px;
  }
  .kpi-value {
      color: #ffffff;
      font-size: 2rem;
      font-weight: 700;
      line-height: 1;
  }
  .kpi-icon {
      font-size: 1.6rem;
      margin-bottom: 8px;
  }
  .kpi-delta {
      color: #43e97b;
      font-size: 0.75rem;
      margin-top: 6px;
      font-weight: 500;
  }

  /* Section header */
  .section-header {
      color: #ffffff;
      font-size: 1.15rem;
      font-weight: 600;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
  }

  /* Weather card */
  .weather-card {
      background: linear-gradient(135deg, rgba(102,126,234,0.25), rgba(118,75,162,0.25));
      border: 1px solid rgba(102,126,234,0.4);
      border-radius: 16px;
      padding: 20px;
      backdrop-filter: blur(10px);
  }

  /* Hero title */
  .hero-title {
      background: linear-gradient(90deg, #667eea, #764ba2, #f093fb);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      font-size: 2.4rem;
      font-weight: 800;
      line-height: 1.1;
  }
  .hero-sub {
      color: rgba(255,255,255,0.55);
      font-size: 0.95rem;
      margin-top: 4px;
  }

  /* Plotly chart containers */
  .chart-container {
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 16px;
      padding: 4px;
  }

  /* Override default Streamlit elements */
  .stMetric { display: none; }
  h1, h2, h3 { color: #ffffff !important; }
  p { color: rgba(255,255,255,0.8); }
  label { color: rgba(255,255,255,0.7) !important; }
  .stDataFrame { border-radius: 12px; overflow: hidden; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# DATA
# ─────────────────────────────────────────────────────────────────
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "ecommerce_orders.csv")

@st.cache_data
def load_data() -> pd.DataFrame:
    df = pd.read_csv(DATA_PATH, parse_dates=["order_date"])
    df["month"] = df["order_date"].dt.to_period("M").astype(str)
    return df

df = load_data()

# ─────────────────────────────────────────────────────────────────
# SIDEBAR — FILTERS
# ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🔍 Filters")
    st.markdown("---")

    # Widget 1 — Category multiselect
    all_cats = sorted(df["category"].unique().tolist())
    selected_cats = st.multiselect(
        "📦 Product Category",
        options=all_cats,
        default=all_cats,
        help="Select one or more product categories",
        key="filter_category",
    )

    # Widget 2 — Region multiselect
    all_regions = sorted(df["region"].unique().tolist())
    selected_regions = st.multiselect(
        "🗺️ Customer Region",
        options=all_regions,
        default=all_regions,
        help="Filter by customer region",
        key="filter_region",
    )

    # Widget 3 — Order status selectbox
    all_statuses = ["All"] + sorted(df["order_status"].unique().tolist())
    selected_status = st.selectbox(
        "📋 Order Status",
        options=all_statuses,
        index=0,
        help="Filter by order status",
        key="filter_status",
    )

    st.markdown("---")
    st.markdown(
        "<small style='color:rgba(255,255,255,0.4)'>RetailPulse Command Center v1.0<br>"
        "Data: Synthetic e-commerce dataset</small>",
        unsafe_allow_html=True,
    )

# ─────────────────────────────────────────────────────────────────
# APPLY FILTERS
# ─────────────────────────────────────────────────────────────────
filtered = df.copy()

if selected_cats:
    filtered = filtered[filtered["category"].isin(selected_cats)]
else:
    filtered = filtered.iloc[0:0]   # empty df

if selected_regions:
    filtered = filtered[filtered["region"].isin(selected_regions)]
else:
    filtered = filtered.iloc[0:0]

if selected_status != "All":
    filtered = filtered[filtered["order_status"] == selected_status]

# ─────────────────────────────────────────────────────────────────
# HEADER
# ─────────────────────────────────────────────────────────────────
col_title, col_date = st.columns([3, 1])
with col_title:
    st.markdown('<div class="hero-title">🛒 RetailPulse Command Center</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div class="hero-sub">Real-time e-commerce intelligence dashboard • '
        f'{datetime.now().strftime("%B %d, %Y")}</div>',
        unsafe_allow_html=True,
    )
with col_date:
    st.markdown("<br>", unsafe_allow_html=True)
    if not filtered.empty:
        date_range = f"{filtered['order_date'].min().strftime('%b %Y')} → {filtered['order_date'].max().strftime('%b %Y')}"
        st.markdown(f"<p style='text-align:right;color:rgba(255,255,255,0.5);font-size:0.8rem'>{date_range}</p>",
                    unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# EMPTY RESULT GUARD
# ─────────────────────────────────────────────────────────────────
if filtered.empty:
    st.warning("⚠️  No data matches your current filter selections. Please broaden your filters to see results.", icon="⚠️")
    st.info("💡  Tip: Make sure at least one Category and one Region are selected.", icon="💡")
    st.stop()

# ─────────────────────────────────────────────────────────────────
# KPI CARDS
# ─────────────────────────────────────────────────────────────────
total_orders = len(filtered)
total_revenue = filtered["revenue"].sum()
avg_order_value = filtered["revenue"].mean()
delivered = filtered[filtered["order_status"] == "Delivered"]
late_count = (delivered["delivery_status"] == "Late").sum()
late_rate = (late_count / len(delivered) * 100) if len(delivered) > 0 else 0

k1, k2, k3, k4 = st.columns(4)

kpi_data = [
    (k1, "📦", "Total Orders",        f"{total_orders:,}",         "orders in selection"),
    (k2, "💰", "Total Revenue",       f"${total_revenue:,.2f}",    "cumulative revenue"),
    (k3, "🛍️", "Avg Order Value",     f"${avg_order_value:,.2f}",  "per order"),
    (k4, "⏰", "Late Delivery Rate",  f"{late_rate:.1f}%",         "of delivered orders"),
]

for col, icon, label, value, delta in kpi_data:
    with col:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-icon">{icon}</div>
            <div class="kpi-label">{label}</div>
            <div class="kpi-value">{value}</div>
            <div class="kpi-delta">{delta}</div>
        </div>
        """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# PLOTLY THEME HELPERS
# ─────────────────────────────────────────────────────────────────
DARK_BG   = "rgba(0,0,0,0)"
FONT_CLR  = "rgba(255,255,255,0.85)"
GRID_CLR  = "rgba(255,255,255,0.08)"
PALETTE   = ["#667eea", "#764ba2", "#f093fb", "#43e97b", "#38f9d7",
             "#fa709a", "#fee140", "#30cfd0"]

def apply_theme(fig, title: str) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, font=dict(color=FONT_CLR, size=16, family="Inter"), x=0.02),
        paper_bgcolor=DARK_BG,
        plot_bgcolor=DARK_BG,
        font=dict(color=FONT_CLR, family="Inter"),
        legend=dict(
            bgcolor="rgba(255,255,255,0.05)",
            bordercolor="rgba(255,255,255,0.1)",
            borderwidth=1,
        ),
        margin=dict(l=20, r=20, t=50, b=20),
    )
    fig.update_xaxes(
        gridcolor=GRID_CLR,
        zerolinecolor=GRID_CLR,
        tickfont=dict(color=FONT_CLR),
    )
    fig.update_yaxes(
        gridcolor=GRID_CLR,
        zerolinecolor=GRID_CLR,
        tickfont=dict(color=FONT_CLR),
    )
    return fig

# ─────────────────────────────────────────────────────────────────
# CHART 1 + CHART 2  (row 1)
# ─────────────────────────────────────────────────────────────────
row1_left, row1_right = st.columns([1.2, 0.8])

# ── Chart 1: Revenue by Category (horizontal bar) ─────────────────
with row1_left:
    rev_by_cat = (
        filtered.groupby("category")["revenue"]
        .sum()
        .reset_index()
        .sort_values("revenue", ascending=True)
    )
    fig_cat = px.bar(
        rev_by_cat,
        x="revenue",
        y="category",
        orientation="h",
        color="revenue",
        color_continuous_scale=["#667eea", "#f093fb", "#fa709a"],
        labels={"revenue": "Revenue ($)", "category": ""},
    )
    fig_cat.update_traces(
        hovertemplate="<b>%{y}</b><br>Revenue: $%{x:,.2f}<extra></extra>",
        marker_line_width=0,
    )
    fig_cat.update_coloraxes(showscale=False)
    fig_cat = apply_theme(fig_cat, "💰 Revenue by Category")
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.plotly_chart(fig_cat, use_container_width=True, config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)

# ── Chart 2: Order Volume Trend (line) ────────────────────────────
with row1_right:
    vol_by_month = (
        filtered.groupby("month")
        .size()
        .reset_index(name="order_count")
        .sort_values("month")
    )
    fig_trend = px.area(
        vol_by_month,
        x="month",
        y="order_count",
        labels={"month": "Month", "order_count": "Orders"},
        color_discrete_sequence=["#43e97b"],
    )
    fig_trend.update_traces(
        fill="tozeroy",
        fillcolor="rgba(67,233,123,0.15)",
        line=dict(color="#43e97b", width=2),
        hovertemplate="<b>%{x}</b><br>Orders: %{y}<extra></extra>",
    )
    fig_trend = apply_theme(fig_trend, "📈 Order Volume Trend")
    fig_trend.update_xaxes(tickangle=-45, nticks=8)
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.plotly_chart(fig_trend, use_container_width=True, config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# CHART 3 + CHART 4  (row 2)
# ─────────────────────────────────────────────────────────────────
row2_left, row2_right = st.columns([0.8, 1.2])

# ── Chart 3: Delivery Performance (donut) ─────────────────────────
with row2_left:
    delivery_counts = (
        filtered["delivery_status"]
        .value_counts()
        .reset_index()
    )
    # Normalize column names across pandas 1.x and 2.x
    delivery_counts.columns = ["status", "count"]

    COLOR_MAP = {"On Time": "#43e97b", "Late": "#fa709a", "Pending": "#fee140"}
    colors = [COLOR_MAP.get(s, "#667eea") for s in delivery_counts["status"]]

    fig_del = go.Figure(go.Pie(
        labels=delivery_counts["status"],
        values=delivery_counts["count"],
        hole=0.55,
        marker=dict(colors=colors, line=dict(color="rgba(0,0,0,0.4)", width=2)),
        hovertemplate="<b>%{label}</b><br>Count: %{value}<br>Share: %{percent}<extra></extra>",
        textfont=dict(color="#ffffff", size=12),
    ))
    fig_del.add_annotation(
        text=f"<b>{len(filtered)}</b><br><span style='font-size:10px'>total</span>",
        x=0.5, y=0.5, showarrow=False,
        font=dict(color="#ffffff", size=18),
    )
    fig_del = apply_theme(fig_del, "🚚 Delivery Performance")
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.plotly_chart(fig_del, use_container_width=True, config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)

# ── Chart 4: Revenue by Region + Status (grouped bar) ────────────
with row2_right:
    rev_region = (
        filtered.groupby(["region", "order_status"])["revenue"]
        .sum()
        .reset_index()
    )
    fig_reg = px.bar(
        rev_region,
        x="region",
        y="revenue",
        color="order_status",
        barmode="group",
        labels={"revenue": "Revenue ($)", "region": "Region", "order_status": "Status"},
        color_discrete_sequence=PALETTE,
    )
    fig_reg.update_traces(
        hovertemplate="<b>%{x}</b><br>%{data.name}: $%{y:,.2f}<extra></extra>",
        marker_line_width=0,
    )
    fig_reg = apply_theme(fig_reg, "🗺️ Revenue by Region & Order Status")
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    st.plotly_chart(fig_reg, use_container_width=True, config={"displayModeBar": False})
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# WEATHER WIDGET  — Open-Meteo API (free, no key)
# ─────────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">🌤️ Live Weather — Major Retail Markets</div>', unsafe_allow_html=True)

CITIES = {
    "New York, NY":       (40.7128,  -74.0060),
    "Los Angeles, CA":    (34.0522, -118.2437),
    "Chicago, IL":        (41.8781,  -87.6298),
    "Houston, TX":        (29.7604,  -95.3698),
    "Phoenix, AZ":        (33.4484, -112.0740),
    "Philadelphia, PA":   (39.9526,  -75.1652),
    "San Antonio, TX":    (29.4241,  -98.4936),
    "Seattle, WA":        (47.6062, -122.3321),
    "Dallas, TX":         (32.7767,  -96.7970),
    "Miami, FL":          (25.7617,  -80.1918),
}

WMO_CODES = {
    0: ("☀️", "Clear sky"),
    1: ("🌤️", "Mainly clear"), 2: ("⛅", "Partly cloudy"), 3: ("☁️", "Overcast"),
    45: ("🌫️", "Fog"), 48: ("🌫️", "Icy fog"),
    51: ("🌦️", "Light drizzle"), 53: ("🌦️", "Drizzle"), 55: ("🌧️", "Heavy drizzle"),
    61: ("🌧️", "Light rain"), 63: ("🌧️", "Rain"), 65: ("🌧️", "Heavy rain"),
    71: ("🌨️", "Light snow"), 73: ("🌨️", "Snow"), 75: ("❄️", "Heavy snow"),
    80: ("🌦️", "Rain showers"), 81: ("🌧️", "Showers"), 82: ("⛈️", "Heavy showers"),
    95: ("⛈️", "Thunderstorm"), 96: ("⛈️", "Thunderstorm + hail"), 99: ("⛈️", "Heavy thunderstorm"),
}

w_col1, w_col2 = st.columns([0.3, 0.7])
with w_col1:
    selected_city = st.selectbox("Select City", list(CITIES.keys()), key="weather_city")

lat, lon = CITIES[selected_city]

def fetch_weather(lat: float, lon: float) -> dict | None:
    """Fetch current weather from Open-Meteo API. Returns parsed dict or None on error."""
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude":        lat,
        "longitude":       lon,
        "current_weather": "true",
        "timezone":        "auto",
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data.get("current_weather")
    except requests.exceptions.Timeout:
        st.error("⏱️ Weather API timed out. Please try again.")
        return None
    except requests.exceptions.ConnectionError:
        st.error("🔌 No internet connection. Weather unavailable.")
        return None
    except requests.exceptions.HTTPError as e:
        st.error(f"🌐 Weather API returned an error: {e}")
        return None
    except Exception as e:
        st.error(f"❌ Unexpected error fetching weather: {e}")
        return None

with w_col2:
    weather = fetch_weather(lat, lon)
    if weather:
        temp_c = weather.get("temperature", "N/A")
        temp_f = round(temp_c * 9 / 5 + 32, 1) if isinstance(temp_c, (int, float)) else "N/A"
        wcode  = weather.get("weathercode", 0)
        wspeed = weather.get("windspeed", "N/A")
        wtime  = weather.get("time", "")
        icon, description = WMO_CODES.get(wcode, ("🌡️", f"Code {wcode}"))

        wc1, wc2, wc3, wc4 = st.columns(4)
        weather_items = [
            (wc1, icon,  description,    "Condition"),
            (wc2, "🌡️", f"{temp_c}°C",  f"({temp_f}°F)"),
            (wc3, "💨", f"{wspeed} km/h","Wind Speed"),
            (wc4, "📍", selected_city.split(",")[1].strip(), "State"),
        ]
        for col, ic, val, lbl in weather_items:
            with col:
                st.markdown(f"""
                <div class="kpi-card">
                    <div class="kpi-icon">{ic}</div>
                    <div class="kpi-label">{lbl}</div>
                    <div class="kpi-value" style="font-size:1.3rem">{val}</div>
                </div>
                """, unsafe_allow_html=True)

        st.markdown(
            "<small style='color:rgba(255,255,255,0.4)'>"
            "Weather data by <a href='https://open-meteo.com' style='color:#667eea'>Open-Meteo.com</a> (CC BY 4.0) · "
            f"Updated: {wtime}"
            "</small>",
            unsafe_allow_html=True,
        )

st.markdown("<br>", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────
# FILTERED DATAFRAME
# ─────────────────────────────────────────────────────────────────
st.markdown(
    f'<div class="section-header">📊 Filtered Orders — {len(filtered):,} records</div>',
    unsafe_allow_html=True,
)

display_cols = [
    "order_id", "order_date", "region", "state", "category",
    "product_name", "quantity", "unit_price", "revenue",
    "order_status", "delivery_status",
]
display_df = filtered[display_cols].copy()
display_df["order_date"] = display_df["order_date"].dt.strftime("%Y-%m-%d")
display_df["revenue"] = display_df["revenue"].map("${:,.2f}".format)
display_df["unit_price"] = display_df["unit_price"].map("${:,.2f}".format)
display_df.columns = [c.replace("_", " ").title() for c in display_df.columns]

st.dataframe(
    display_df,
    use_container_width=True,
    height=380,
    hide_index=True,
)

st.markdown("<br>", unsafe_allow_html=True)
st.markdown(
    "<p style='text-align:center;color:rgba(255,255,255,0.3);font-size:0.75rem'>"
    "RetailPulse Command Center · Built with Streamlit · "
    "Weather data by <a href='https://open-meteo.com' style='color:#667eea'>Open-Meteo.com</a> (CC BY 4.0)"
    "</p>",
    unsafe_allow_html=True,
)
