"""
generate_data.py – Creates data/ecommerce_orders.csv with 350 synthetic rows.
Run once: python generate_data.py
"""

import os
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

# ── Config ──────────────────────────────────────────────────────────────────
N = 350

CATEGORIES = [
    "Electronics", "Clothing", "Books",
    "Home & Garden", "Sports", "Beauty", "Food & Grocery", "Toys",
]

REGIONS = ["Northeast", "Southeast", "Midwest", "Southwest", "West"]

STATE_MAP = {
    "Northeast":  ["New York", "Massachusetts", "Pennsylvania", "New Jersey", "Connecticut"],
    "Southeast":  ["Florida", "Georgia", "North Carolina", "Virginia", "Tennessee"],
    "Midwest":    ["Illinois", "Ohio", "Michigan", "Indiana", "Wisconsin"],
    "Southwest":  ["Texas", "Arizona", "New Mexico", "Oklahoma", "Arkansas"],
    "West":       ["California", "Washington", "Oregon", "Colorado", "Nevada"],
}

ORDER_STATUSES = ["Delivered", "Pending", "Processing", "Cancelled", "Returned"]
STATUS_WEIGHTS = [0.55, 0.12, 0.15, 0.10, 0.08]

PRODUCTS = {
    "Electronics":    ["Laptop", "Smartphone", "Tablet", "Headphones", "Smart Watch", "Camera", "Bluetooth Speaker"],
    "Clothing":       ["T-Shirt", "Jeans", "Dress", "Jacket", "Sneakers", "Sweater", "Shorts"],
    "Books":          ["Fiction Novel", "Self-Help Book", "Textbook", "Comic Collection", "Cookbook", "Biography"],
    "Home & Garden":  ["Sofa", "Coffee Table", "Plant Pot", "LED Lamp", "Area Rug", "Curtains", "Bookshelf"],
    "Sports":         ["Yoga Mat", "Dumbbell Set", "Running Shoes", "Basketball", "Tennis Racket", "Bicycle"],
    "Beauty":         ["Face Serum", "Lipstick Set", "Mascara", "Moisturizer", "Perfume", "Shampoo"],
    "Food & Grocery": ["Coffee Beans", "Protein Bars", "Olive Oil", "Granola Mix", "Premium Tea", "Spice Kit"],
    "Toys":           ["Building Blocks", "Board Game", "Stuffed Animal", "RC Car", "Jigsaw Puzzle", "Art Kit"],
}

PRICE_RANGES = {
    "Electronics":    (49.99,  1999.99),
    "Clothing":       (14.99,   199.99),
    "Books":          ( 7.99,    79.99),
    "Home & Garden":  (19.99,   799.99),
    "Sports":         (14.99,   499.99),
    "Beauty":         ( 9.99,   149.99),
    "Food & Grocery": ( 4.99,    59.99),
    "Toys":           ( 9.99,    99.99),
}

START_DATE = datetime(2023, 1, 1)
END_DATE   = datetime(2024, 12, 31)
DATE_RANGE = (END_DATE - START_DATE).days

# ── Generation ───────────────────────────────────────────────────────────────
rows = []
for i in range(1, N + 1):
    category = random.choice(CATEGORIES)
    region   = random.choices(REGIONS, weights=[0.22, 0.18, 0.20, 0.17, 0.23])[0]
    state    = random.choice(STATE_MAP[region])
    product  = random.choice(PRODUCTS[category])
    qty      = random.randint(1, 5)
    lo, hi   = PRICE_RANGES[category]
    price    = round(random.uniform(lo, hi), 2)
    revenue  = round(qty * price, 2)

    order_date = START_DATE + timedelta(days=random.randint(0, DATE_RANGE))

    status = random.choices(ORDER_STATUSES, weights=STATUS_WEIGHTS)[0]

    if status == "Delivered":
        days_deliver = random.randint(1, 14)
        is_late = days_deliver > 7
    elif status in ("Processing", "Pending"):
        days_deliver = None
        is_late = False
    else:
        days_deliver = random.randint(1, 14) if status == "Returned" else None
        is_late = False

    delivery_status = (
        "Late" if is_late else
        "On Time" if status == "Delivered" else
        "Pending"
    )

    rows.append({
        "order_id":        f"ORD-{10000 + i}",
        "order_date":      order_date.strftime("%Y-%m-%d"),
        "customer_id":     f"CUST-{random.randint(1000, 9999)}",
        "region":          region,
        "state":           state,
        "category":        category,
        "product_name":    product,
        "quantity":        qty,
        "unit_price":      price,
        "revenue":         revenue,
        "order_status":    status,
        "delivery_status": delivery_status,
        "days_to_deliver": days_deliver,
    })

df = pd.DataFrame(rows)
df["order_date"] = pd.to_datetime(df["order_date"])
df = df.sort_values("order_date").reset_index(drop=True)

os.makedirs("data", exist_ok=True)
df.to_csv("data/ecommerce_orders.csv", index=False)
print(f"[OK] Generated {len(df)} rows -> data/ecommerce_orders.csv")
print(df.head(3).to_string())
