# 🛒 RetailPulse Command Center

> A professional, interactive Streamlit e-commerce analytics dashboard with real-time weather data.

[![Streamlit](https://img.shields.io/badge/Built%20with-Streamlit-FF4B4B?logo=streamlit)](https://streamlit.io)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python)](https://python.org)
[![Open-Meteo](https://img.shields.io/badge/Weather-Open--Meteo-00AAFF)](https://open-meteo.com)

---

## 📋 Project Description

RetailPulse Command Center is a fully interactive Streamlit dashboard designed to give e-commerce teams instant visibility into their sales performance. It combines a synthetic 350-row order dataset with live weather data to demonstrate a complete analytics workflow: from raw data through interactive filtering, KPI computation, charting, and live API integration.

---

## ✨ Dashboard Features

| Feature | Description |
|---|---|
| **3 Interactive Filters** | Category, Region, and Order Status widgets that cascade across all charts and KPIs |
| **4 KPI Cards** | Total Orders · Total Revenue · Avg Order Value · Late Delivery Rate |
| **4 Plotly Charts** | Revenue by Category, Order Volume Trend, Delivery Performance Donut, Revenue by Region |
| **Filtered Dataframe** | `st.dataframe` that reflects the exact filtered row set |
| **Empty-Result Handling** | Clear warning + tip when no data matches the filter combination |
| **Live Weather Widget** | Real-time weather for 10 US retail markets via Open-Meteo API |
| **Premium Dark UI** | Glassmorphism cards, gradient animations, Google Fonts (Inter) |

---

## 🎛️ Widget Explanation

### Widget 1 — Product Category (Multiselect)
```
Location: Sidebar
Type: st.multiselect
Options: Electronics, Clothing, Books, Home & Garden, Sports, Beauty, Food & Grocery, Toys
Default: All categories selected
Effect: Filters ALL charts and the dataframe simultaneously
```
Selecting a subset of categories will immediately update the KPI cards, all four charts, and the raw data table to show only orders matching those categories.

### Widget 2 — Customer Region (Multiselect)
```
Location: Sidebar
Type: st.multiselect
Options: Northeast, Southeast, Midwest, Southwest, West
Default: All regions selected
Effect: Filters ALL charts and the dataframe simultaneously
```
Deselecting a region removes those orders from the entire dashboard in real time.

### Widget 3 — Order Status (Selectbox)
```
Location: Sidebar
Type: st.selectbox
Options: All, Delivered, Pending, Processing, Cancelled, Returned
Default: All
Effect: Filters ALL charts and the dataframe simultaneously
```
Choosing "Delivered" shows only completed orders; choosing "Cancelled" isolates lost revenue.

### Widget 4 — Weather City (Selectbox)
```
Location: Weather section (main panel)
Type: st.selectbox
Options: 10 major US cities (New York, LA, Chicago, Houston, Phoenix, ...)
Effect: Triggers a live GET request to Open-Meteo for the selected city's weather
```

---

## 📊 Chart Explanation

### Chart 1 — Revenue by Category (Horizontal Bar)
Shows total revenue earned per product category in the current filter selection. Uses a colour gradient from purple to pink. Allows instant comparison of category performance.

### Chart 2 — Order Volume Trend (Area Line)
Monthly order count plotted as a green area chart. Shows seasonality, growth, and decline in order volume over the 2023–2024 period. All filter changes update the time series.

### Chart 3 — Delivery Performance (Donut)
Breakdown of orders by delivery status (On Time / Late / Pending). The center annotation shows the total order count. Colour-coded: green = on time, red = late, yellow = pending.

### Chart 4 — Revenue by Region & Status (Grouped Bar)
Compares revenue contribution across the five US regions, further broken down by order status. Identifies which regions produce the most delivered vs. cancelled revenue.

---

## 🌤️ External API — Open-Meteo

### API Details

| Field | Value |
|---|---|
| **Provider** | Open-Meteo |
| **Endpoint** | `https://api.open-meteo.com/v1/forecast` |
| **HTTP Method** | `GET` |
| **Authentication** | None (completely free and keyless) |
| **Request Timeout** | 10 seconds |

### GET Request Parameters

```
latitude        = <city latitude>
longitude       = <city longitude>
current_weather = true
timezone        = auto
```

### JSON Fields Used

| JSON Path | Description |
|---|---|
| `current_weather.temperature` | Current temperature in °C |
| `current_weather.weathercode` | WMO weather code (integer) |
| `current_weather.windspeed` | Wind speed in km/h |
| `current_weather.time` | Timestamp of the measurement |

### API Explanation (In My Own Words)

Open-Meteo is a free, open-source weather API that provides forecast and current weather data without requiring any API key or account registration. You simply make an HTTP GET request with the latitude and longitude of your location, and it returns a JSON response with real-time atmospheric data. I use it to display the current temperature and weather condition (like "Clear sky" or "Thunderstorm") for whichever US city the user selects, making the dashboard feel connected to the real world. The weather codes follow the World Meteorological Organization (WMO) standard, which I translate into human-readable descriptions and emoji icons.

### Exception Handling

The app handles the following error conditions gracefully:
- `requests.exceptions.Timeout` — 10-second timeout exceeded
- `requests.exceptions.ConnectionError` — No internet connection
- `requests.exceptions.HTTPError` — 4xx/5xx API response
- Generic `Exception` — Unexpected errors

---

## 📜 Attribution

> **Weather data by [Open-Meteo.com](https://open-meteo.com) (CC BY 4.0)**
> Open-Meteo is an open-source project and is free to use for non-commercial applications.

---

## 🚀 Local Run Instructions

### Prerequisites
- Python 3.10 or higher
- pip

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/retailpulse-part3-dashboard.git
cd retailpulse-part3-dashboard

# 2. (Optional) Create a virtual environment
python -m venv venv
venv\Scripts\activate       # Windows
# source venv/bin/activate  # macOS/Linux

# 3. Install dependencies
pip install -r requirements.txt

# 4. Generate the dataset (run once)
python generate_data.py

# 5. Launch the dashboard
streamlit run app.py
```

The dashboard will open automatically at `http://localhost:8501`.

---

## ☁️ Deployment Instructions (Streamlit Community Cloud)

1. Push this repository to GitHub (must be public or connected to Streamlit Cloud).
2. Go to [share.streamlit.io](https://share.streamlit.io) and sign in with GitHub.
3. Click **New app** → select your repository.
4. Set **Main file path** to `app.py`.
5. Click **Deploy**.
6. Wait ~2 minutes for the build to complete.

> **Important**: Make sure `data/ecommerce_orders.csv` is committed to the repository (run `python generate_data.py` locally first, then `git add data/ecommerce_orders.csv`).

---

## 🌐 Deployed Application URL

> **Streamlit Public URL:** *(Deploy the app and paste your URL here)*
> 
> `https://share.streamlit.io/YOUR_USERNAME/retailpulse-part3-dashboard/main/app.py`

---

## 📁 Project Structure

```
retailpulse-part3-dashboard/
├── data/
│   └── ecommerce_orders.csv   # 350-row synthetic e-commerce dataset
├── app.py                      # Main Streamlit dashboard
├── generate_data.py            # Script to regenerate the dataset
├── requirements.txt
├── README.md
└── .gitignore
```
