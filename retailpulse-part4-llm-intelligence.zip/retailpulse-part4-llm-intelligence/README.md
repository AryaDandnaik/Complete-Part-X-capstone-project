# 🤖 RetailPulse AI Customer Intelligence Copilot

> Part 4 Academic Project: Structured LLM Extraction + RAG Document QA

[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python)](https://python.org)
[![Pydantic](https://img.shields.io/badge/Pydantic-v2-E92063?logo=pydantic)](https://docs.pydantic.dev)
[![FAISS](https://img.shields.io/badge/Vector%20Store-FAISS-00AAFF)](https://faiss.ai)
[![HuggingFace](https://img.shields.io/badge/LLM-HuggingFace-FFD21E?logo=huggingface)](https://huggingface.co)

---

## 📋 Project Description

RetailPulse AI Customer Intelligence Copilot is a two-pipeline AI system built for academic demonstration of:

1. **Pipeline A (Structured Extraction)**: Classify and extract structured information from fictional customer support tickets using an LLM with Pydantic schema validation.
2. **Pipeline B (RAG)**: Answer natural language questions about RetailPulse policies using Retrieval-Augmented Generation (FAISS + sentence-transformers + LLM).

---

## 🏗️ Repository Structure

```
retailpulse-part4-llm-intelligence/
├── data/
│   ├── support_tickets.csv        # 23 fictional customer support messages
│   └── documents/                 # 6 RetailPulse policy documents
│       ├── returns_refunds.txt
│       ├── delivery_late_orders.txt
│       ├── payment_billing.txt
│       ├── customer_support_escalation.txt
│       ├── seller_operations.txt
│       └── privacy_data_handling.txt
├── src/
│   ├── schema.py        # Pydantic models (enums + validation)
│   ├── extraction.py    # Pipeline A — LLM extraction
│   ├── rag.py           # Pipeline B — RAG QA
│   └── validation.py    # Validation demo (PASS / FAIL)
├── outputs/             # Auto-generated results
│   ├── extraction_results.json
│   ├── validation_errors.json
│   └── rag_demo.md
├── requirements.txt
├── README.md
├── .env.example
└── .gitignore
```

---

## ⚙️ Technology Stack

### LLM

| Scenario | Model |
|---|---|
| **No API key (default)** | `google/flan-t5-base` — free, local, no registration required |
| **With API key** | `gpt-3.5-turbo` via OpenAI API |

**Reason for flan-t5-base**: Completely free, runs offline, no API keys, ~300MB, and handles instruction-following well enough for the classification + summarisation tasks in this project.

### Embedding Model

**`sentence-transformers/all-MiniLM-L6-v2`**

**Reason**: Industry-standard lightweight embedding model (384 dimensions), excellent semantic similarity quality for its size, runs locally with no API key, widely used in academic RAG demonstrations.

### Vector Store

**FAISS (faiss-cpu)**

**Reason**: In-memory vector database with no server required. Ideal for academic demos where persistence isn't needed. Supports millions of vectors with sub-millisecond search. Maintained by Meta AI Research.

---

## 🔐 API Environment Variable

| Variable | Description | Required |
|---|---|---|
| `OPENAI_API_KEY` | OpenAI API key for gpt-3.5-turbo | No (falls back to local) |
| `OPENAI_MODEL` | OpenAI model name | No (default: gpt-3.5-turbo) |

Copy `.env.example` to `.env` and fill in your key if you have one. If not, everything works offline.

```bash
cp .env.example .env
# Edit .env and set OPENAI_API_KEY=sk-...
```

---

## 🚀 Quick Start

### Prerequisites

```bash
Python 3.10+
pip
```

### Install

```bash
pip install -r requirements.txt
```

> ⚠️ **Note**: First run of `src/rag.py` will download `flan-t5-base` (~300MB) and `all-MiniLM-L6-v2` (~90MB) from HuggingFace. Subsequent runs use the local cache.

### Run Validation Demo (fully offline)

```bash
python src/validation.py
```

Expected output:
```
[TEST 1] VALID fixture
✅  PASS — Validation succeeded

[TEST 2] MALFORMED fixture (invalid enum values)
✅  FAIL correctly detected — Validation caught the error as expected

VALIDATION SUMMARY
Valid fixture     → PASS ✅
Malformed fixture → FAIL correctly detected ✅
```

### Run Extraction Pipeline

```bash
python src/extraction.py
```

Outputs: `outputs/extraction_results.json`, `outputs/validation_errors.json`

### Run RAG Demo

```bash
python src/rag.py
```

Outputs: `outputs/rag_demo.md`

---

## ✅ Pydantic Validation Schema

### `TicketExtraction` Model

| Field | Type | Allowed Values |
|---|---|---|
| `category` | `Category` enum | `DELIVERY`, `PAYMENT`, `PRODUCT`, `ACCOUNT`, `REFUND`, `OTHER` |
| `urgency` | `Urgency` enum | `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` |
| `sentiment` | `Sentiment` enum | `POSITIVE`, `NEUTRAL`, `NEGATIVE` |
| `summary` | `str` | 5–300 characters, non-blank |

### Validation Failure — Malformed Fixture

The malformed fixture (`T_MALFORMED_999`) contains:
- `"category": "LOGISTICS"` — ❌ not a valid `Category` enum value
- `"urgency": "SUPER_URGENT"` — ❌ not a valid `Urgency` enum value

**Pydantic v2 behaviour**: Raises `ValidationError` listing each invalid field with its input value and error message. The record is:
1. **NOT saved** to `extraction_results.json`
2. **Logged** to `validation_errors.json` with full error details
3. **Flagged** for manual review or re-extraction

This demonstrates production-grade data quality enforcement — bad LLM outputs are caught before entering downstream systems.

---

## 🔍 RAG Pipeline — How It Works

```
User Query
    │
    ▼
[1] load_documents()      ← Read 6 .txt policy files
    │
    ▼
[2] chunk_documents()     ← Split into ~400-char overlapping chunks
    │
    ▼
[3] create_embeddings()   ← all-MiniLM-L6-v2 → float32 vectors
    │
    ▼
[4] build_vector_store()  ← FAISS IndexFlatL2
    │
    ▼
[5] retrieve_documents()  ← Top-K semantic search
    │
    ▼
[6] generate_grounded_answer() ← Prompt + context → LLM
    │
    ▼
Grounded answer + source citations
```

### RAG Prompt Design

The generation prompt explicitly instructs the LLM to:
- Use ONLY the supplied context
- NOT invent information
- Say so if the answer is unavailable in the documents
- Cite source document names

---

## 💬 RAG Demo Examples

Five example questions and their source documents:

| # | Question | Source Documents |
|---|---|---|
| 1 | What is the return window for electronics? | `returns_refunds.txt` |
| 2 | How long does a refund take after returning an item? | `returns_refunds.txt` |
| 3 | What happens if my package is lost? | `delivery_late_orders.txt` |
| 4 | How do I report a duplicate charge? | `payment_billing.txt` |
| 5 | What are RetailPulse's seller commission rates? | `seller_operations.txt` |

Full questions, retrieved chunks, and answers are in `outputs/rag_demo.md` after running `python src/rag.py`.

---

## 📚 Policy Documents

| Document | Topics Covered |
|---|---|
| `returns_refunds.txt` | Return windows, conditions, how to return, refund timeline, non-returnable items |
| `delivery_late_orders.txt` | Delivery timelines, tracking, late order compensation, lost packages |
| `payment_billing.txt` | Payment methods, billing errors, duplicate charges, security |
| `customer_support_escalation.txt` | 4-tier support model, SLAs, escalation triggers |
| `seller_operations.txt` | Seller onboarding, KPIs, commission rates, payouts |
| `privacy_data_handling.txt` | Data collection, GDPR/CCPA rights, retention, security |

---

## 🧪 Offline vs. Live Tests

| Test | Online Required? | Command |
|---|---|---|
| Pydantic validation (PASS) | No | `python src/validation.py` |
| Pydantic validation (FAIL) | No | `python src/validation.py` |
| FAISS index build | No | `python src/rag.py` |
| Embedding (MiniLM) | First run only (downloads model) | `python src/rag.py` |
| LLM generation (flan-t5) | First run only (downloads model) | `python src/rag.py` |
| LLM generation (OpenAI) | Yes (requires key + internet) | Set `OPENAI_API_KEY` in `.env` |
