"""
schema.py – Pydantic v2 models for structured customer support extraction.
"""

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


# ── Enumerations ─────────────────────────────────────────────────────────────

class Category(str, Enum):
    DELIVERY = "DELIVERY"
    PAYMENT  = "PAYMENT"
    PRODUCT  = "PRODUCT"
    ACCOUNT  = "ACCOUNT"
    REFUND   = "REFUND"
    OTHER    = "OTHER"


class Urgency(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


class Sentiment(str, Enum):
    POSITIVE = "POSITIVE"
    NEUTRAL  = "NEUTRAL"
    NEGATIVE = "NEGATIVE"


# ── Main Schema ───────────────────────────────────────────────────────────────

class TicketExtraction(BaseModel):
    """
    Structured representation of a customer support ticket.
    Validated by Pydantic v2 with strict enum enforcement.
    """

    category:  Category  = Field(..., description="Primary topic of the ticket")
    urgency:   Urgency   = Field(..., description="Urgency level of the ticket")
    sentiment: Sentiment = Field(..., description="Customer sentiment")
    summary:   str       = Field(..., min_length=5, max_length=300,
                                 description="One-sentence summary of the issue")

    @field_validator("summary")
    @classmethod
    def summary_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("summary must not be blank")
        return v.strip()


# ── Batch Wrapper ─────────────────────────────────────────────────────────────

class ExtractionResult(BaseModel):
    """Single record with original ticket ID and extracted fields."""

    ticket_id: str
    message:   str
    extracted: Optional[TicketExtraction] = None
    error:     Optional[str]              = None
    status:    str = "success"            # "success" | "error"
