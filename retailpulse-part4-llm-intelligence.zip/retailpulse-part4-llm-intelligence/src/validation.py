"""
validation.py — Pydantic Validation Demo for RetailPulse Part 4

Demonstrates:
  1. VALID ticket   → ExtractionResult with status="success"  → PASS
  2. MALFORMED fixture (invalid enum) → ValidationError caught → FAIL (correctly)

Run: python src/validation.py
"""

import json
import sys
from pathlib import Path

from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).parent.parent))
from src.schema import TicketExtraction, ExtractionResult

ROOT    = Path(__file__).parent.parent
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────────
# TEST FIXTURES
# ─────────────────────────────────────────────────────────────────

VALID_FIXTURE = {
    "ticket_id": "T_VALID_001",
    "message":   "My order hasn't arrived yet. It's been 5 days past the expected date.",
    "raw_extraction": {
        "category":  "DELIVERY",
        "urgency":   "HIGH",
        "sentiment": "NEGATIVE",
        "summary":   "Customer reports their order is 5 days overdue and has not yet arrived.",
    },
}

# Intentionally malformed: "category" has an invalid enum value "LOGISTICS"
# and "urgency" has an invalid value "SUPER_URGENT"
MALFORMED_FIXTURE = {
    "ticket_id": "T_MALFORMED_999",
    "message":   "This is a test malformed fixture with invalid enum values.",
    "raw_extraction": {
        "category":  "LOGISTICS",          # ❌ invalid — not in Category enum
        "urgency":   "SUPER_URGENT",       # ❌ invalid — not in Urgency enum
        "sentiment": "NEGATIVE",           # ✅ valid
        "summary":   "Test malformed data with invalid enum fields.",  # ✅ valid
    },
}


# ─────────────────────────────────────────────────────────────────
# VALIDATION RUNNER
# ─────────────────────────────────────────────────────────────────

def validate_fixture(fixture: dict) -> tuple[bool, dict]:
    """
    Attempt to validate raw extraction data through Pydantic.
    Returns (passed: bool, result_dict: dict)
    """
    tid     = fixture["ticket_id"]
    msg     = fixture["message"]
    raw     = fixture["raw_extraction"]

    try:
        extracted = TicketExtraction(**raw)
        result    = ExtractionResult(
            ticket_id=tid,
            message=msg,
            extracted=extracted,
            status="success",
        )
        return True, result.model_dump()

    except ValidationError as e:
        error_details = {
            "ticket_id": tid,
            "message":   msg,
            "raw_data":  raw,
            "error":     e.errors(),
            "status":    "validation_failed",
            "handling_decision": (
                "Record rejected. Will NOT be saved to extraction_results.json. "
                "Logged to validation_errors.json for review. "
                "Manual triage or re-extraction required."
            ),
        }
        return False, error_details


# ─────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────

def main():
    print(f"\n{'='*65}")
    print("  RetailPulse Part 4 — Pydantic Validation Demo")
    print(f"{'='*65}\n")

    validation_log = []

    # ── TEST 1: Valid fixture ──────────────────────────────────────
    print("  [TEST 1] VALID fixture")
    print(f"  Ticket : {VALID_FIXTURE['ticket_id']}")
    print(f"  Data   : {json.dumps(VALID_FIXTURE['raw_extraction'], indent=2)}")
    print()

    passed, result = validate_fixture(VALID_FIXTURE)

    if passed:
        extracted = result["extracted"]
        print(f"  ✅  PASS — Validation succeeded")
        print(f"       category  = {extracted['category']}")
        print(f"       urgency   = {extracted['urgency']}")
        print(f"       sentiment = {extracted['sentiment']}")
        print(f"       summary   = {extracted['summary'][:60]}…")
    else:
        print(f"  ❌  UNEXPECTED FAILURE: {result}")

    validation_log.append({"test": "valid_fixture", "passed": passed, "result": result})

    print(f"\n{'─'*65}\n")

    # ── TEST 2: Malformed fixture ──────────────────────────────────
    print("  [TEST 2] MALFORMED fixture (invalid enum values)")
    print(f"  Ticket : {MALFORMED_FIXTURE['ticket_id']}")
    print(f"  Data   : {json.dumps(MALFORMED_FIXTURE['raw_extraction'], indent=2)}")
    print()

    passed2, result2 = validate_fixture(MALFORMED_FIXTURE)

    if not passed2:
        print(f"  ✅  FAIL correctly detected — Validation caught the error as expected")
        print(f"\n  Pydantic Error Details:")
        for err in result2["error"]:
            print(f"    • Field : {' → '.join(str(x) for x in err['loc'])}")
            print(f"      Input : {err.get('input', 'N/A')}")
            print(f"      Error : {err['msg']}")
        print(f"\n  Handling Decision:")
        print(f"    {result2['handling_decision']}")
    else:
        print(f"  ❌  UNEXPECTED PASS — malformed data should have failed")

    validation_log.append({"test": "malformed_fixture", "passed": passed2, "result": result2})

    # ── Save validation log ───────────────────────────────────────
    log_path = OUTPUTS / "validation_errors.json"
    # Only log the failures
    failures = [entry for entry in validation_log if not entry["passed"]]
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(failures, f, indent=2, default=str)

    print(f"\n{'─'*65}")
    print(f"\n  📋 VALIDATION SUMMARY")
    print(f"  ─────────────────────────────────────────────────────")
    print(f"  Valid fixture    → {'PASS ✅' if validation_log[0]['passed'] else 'FAIL ❌'}")
    print(f"  Malformed fixture→ {'FAIL correctly detected ✅' if not validation_log[1]['passed'] else 'UNEXPECTED PASS ❌'}")
    print(f"\n  Validation errors saved → {log_path}")

    print(f"\n{'='*65}\n")

    # Exit code: 0 if both tests behaved as expected
    both_correct = validation_log[0]["passed"] and not validation_log[1]["passed"]
    sys.exit(0 if both_correct else 1)


if __name__ == "__main__":
    main()
