"""
rag.py — Pipeline B: RAG Document Question Answering

Functions:
    load_documents()          → list[dict]
    chunk_documents()         → list[dict]
    create_embeddings()       → np.ndarray
    build_vector_store()      → faiss.IndexFlatL2
    retrieve_documents()      → list[dict]
    generate_grounded_answer()→ str

Embedding model : sentence-transformers/all-MiniLM-L6-v2
Vector store    : FAISS (faiss-cpu)
LLM             : OpenAI (if OPENAI_API_KEY set) else flan-t5-base (local)

Run: python src/rag.py
Output: outputs/rag_demo.md
"""

import json
import os
import sys
import textwrap
from pathlib import Path

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).parent.parent))

# ─────────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────────
ROOT     = Path(__file__).parent.parent
DOC_DIR  = ROOT / "data" / "documents"
OUTPUTS  = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)
DEMO_OUT = OUTPUTS / "rag_demo.md"

# ─────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────
CHUNK_SIZE    = 400    # characters per chunk
CHUNK_OVERLAP = 80     # overlap between chunks
TOP_K         = 3      # retrieved chunks per query
EMBED_MODEL   = "sentence-transformers/all-MiniLM-L6-v2"
USE_OPENAI    = bool(os.getenv("OPENAI_API_KEY"))

# ─────────────────────────────────────────────────────────────────
# STEP 1: LOAD DOCUMENTS
# ─────────────────────────────────────────────────────────────────
def load_documents() -> list[dict]:
    """
    Load all .txt files from data/documents/.
    Returns a list of dicts: {source, content}
    """
    docs = []
    for path in sorted(DOC_DIR.glob("*.txt")):
        text = path.read_text(encoding="utf-8")
        docs.append({"source": path.name, "content": text})
    print(f"  ✅ Loaded {len(docs)} documents: {[d['source'] for d in docs]}")
    return docs


# ─────────────────────────────────────────────────────────────────
# STEP 2: CHUNK DOCUMENTS
# ─────────────────────────────────────────────────────────────────
def chunk_documents(docs: list[dict]) -> list[dict]:
    """
    Split each document into overlapping character chunks.
    Returns list of dicts: {source, chunk_id, text}
    """
    chunks = []
    for doc in docs:
        text   = doc["content"]
        source = doc["source"]
        start  = 0
        idx    = 0
        while start < len(text):
            end  = min(start + CHUNK_SIZE, len(text))
            chunk_text = text[start:end].strip()
            if len(chunk_text) > 30:   # skip tiny trailing fragments
                chunks.append({
                    "source":   source,
                    "chunk_id": f"{source}::chunk_{idx}",
                    "text":     chunk_text,
                })
                idx += 1
            start = end - CHUNK_OVERLAP
            if start >= len(text):
                break

    print(f"  ✅ Created {len(chunks)} chunks from {len(docs)} documents")
    return chunks


# ─────────────────────────────────────────────────────────────────
# STEP 3: CREATE EMBEDDINGS
# ─────────────────────────────────────────────────────────────────
_embed_model = None

def _get_embed_model() -> SentenceTransformer:
    global _embed_model
    if _embed_model is None:
        print(f"  ↳ Loading embedding model: {EMBED_MODEL}")
        _embed_model = SentenceTransformer(EMBED_MODEL)
    return _embed_model


def create_embeddings(chunks: list[dict]) -> np.ndarray:
    """
    Embed all chunks using sentence-transformers/all-MiniLM-L6-v2.
    Returns float32 numpy array of shape (n_chunks, 384).
    """
    model  = _get_embed_model()
    texts  = [c["text"] for c in chunks]
    vectors = model.encode(texts, show_progress_bar=True, convert_to_numpy=True)
    vectors = vectors.astype("float32")
    print(f"  ✅ Embedded {len(chunks)} chunks → shape {vectors.shape}")
    return vectors


# ─────────────────────────────────────────────────────────────────
# STEP 4: BUILD VECTOR STORE
# ─────────────────────────────────────────────────────────────────
def build_vector_store(embeddings: np.ndarray) -> faiss.IndexFlatL2:
    """
    Build a FAISS flat L2 index from the embedding matrix.
    Returns the populated index.
    """
    dim   = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    print(f"  ✅ FAISS index built — {index.ntotal} vectors, dim={dim}")
    return index


# ─────────────────────────────────────────────────────────────────
# STEP 5: RETRIEVE DOCUMENTS
# ─────────────────────────────────────────────────────────────────
def retrieve_documents(
    query: str,
    index: faiss.IndexFlatL2,
    chunks: list[dict],
    k: int = TOP_K,
) -> list[dict]:
    """
    Embed the query and retrieve top-k most similar chunks from FAISS.
    Returns list of chunk dicts with added 'score' field.
    """
    model    = _get_embed_model()
    q_vec    = model.encode([query], convert_to_numpy=True).astype("float32")
    distances, indices = index.search(q_vec, k)

    results = []
    for dist, idx in zip(distances[0], indices[0]):
        if idx < 0 or idx >= len(chunks):
            continue
        chunk = dict(chunks[idx])
        chunk["score"] = float(dist)
        results.append(chunk)
    return results


# ─────────────────────────────────────────────────────────────────
# STEP 6: GENERATE GROUNDED ANSWER
# ─────────────────────────────────────────────────────────────────
RAG_SYSTEM = """You are RetailPulse's intelligent support assistant.
Answer the user's question using ONLY the context provided below.
Do NOT invent information. If the answer is not present in the context, say:
"I'm sorry, I don't have enough information in the available documents to answer that."
Always cite the source document name(s) at the end of your answer.
"""

def _build_rag_prompt(query: str, retrieved: list[dict]) -> str:
    context_parts = []
    for i, chunk in enumerate(retrieved, 1):
        context_parts.append(
            f"[Source {i}: {chunk['source']}]\n{chunk['text']}"
        )
    context = "\n\n".join(context_parts)
    return f"""{RAG_SYSTEM}

--- CONTEXT ---
{context}
--- END CONTEXT ---

Question: {query}

Answer (cite source document names):"""


def _answer_with_openai(prompt: str) -> str:
    import openai
    model  = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
    client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    resp   = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        max_tokens=400,
    )
    return resp.choices[0].message.content.strip()


_t5_pipe = None
def _get_t5_pipe():
    global _t5_pipe
    if _t5_pipe is None:
        from transformers import pipeline as hf_pipeline
        print("  ↳ Loading flan-t5-base for answer generation…")
        _t5_pipe = hf_pipeline("text2text-generation", model="google/flan-t5-base", max_new_tokens=200)
    return _t5_pipe


def _answer_with_local(prompt: str) -> str:
    pipe   = _get_t5_pipe()
    # T5 has input length limits; truncate context if needed
    trunc  = prompt[:2000]
    result = pipe(trunc)[0]["generated_text"].strip()
    return result if result else "Based on the provided documents, no specific answer could be generated."


def generate_grounded_answer(query: str, retrieved: list[dict]) -> str:
    """
    Send retrieved context + query to LLM and return grounded answer.
    Uses OpenAI if available, else local flan-t5.
    """
    prompt = _build_rag_prompt(query, retrieved)
    if USE_OPENAI:
        return _answer_with_openai(prompt)
    else:
        return _answer_with_local(prompt)


# ─────────────────────────────────────────────────────────────────
# DEMO QUESTIONS
# ─────────────────────────────────────────────────────────────────
DEMO_QUESTIONS = [
    "What is RetailPulse's return window for electronics?",
    "How long does it take to get a refund after returning an item?",
    "What happens if my package is lost during delivery?",
    "How do I report a duplicate charge on my order?",
    "What are RetailPulse's seller commission rates?",
    "What personal data does RetailPulse collect from customers?",
    "How can I escalate my complaint to a senior support agent?",
]


# ─────────────────────────────────────────────────────────────────
# MAIN RAG DEMO
# ─────────────────────────────────────────────────────────────────
def run_rag_demo():
    print(f"\n{'='*65}")
    print("  Pipeline B — RAG Document Question Answering")
    print(f"  Embedding model : {EMBED_MODEL}")
    print(f"  Vector store    : FAISS (in-memory)")
    print(f"  LLM backend     : {'OpenAI (' + os.getenv('OPENAI_MODEL','gpt-3.5-turbo') + ')' if USE_OPENAI else 'Local (flan-t5-base)'}")
    print(f"  Top-K retrieval : {TOP_K}")
    print(f"{'='*65}\n")

    # Build pipeline
    docs       = load_documents()
    chunks     = chunk_documents(docs)
    embeddings = create_embeddings(chunks)
    index      = build_vector_store(embeddings)

    print(f"\n  Pipeline ready. Running {len(DEMO_QUESTIONS)} demo questions…\n")

    demo_sections = []

    for q_num, question in enumerate(DEMO_QUESTIONS, 1):
        print(f"\n{'─'*65}")
        print(f"  Q{q_num}: {question}")
        print(f"{'─'*65}")

        retrieved = retrieve_documents(question, index, chunks, k=TOP_K)
        answer    = generate_grounded_answer(question, retrieved)

        # Console output
        print(f"\n  📚 Retrieved {len(retrieved)} chunks:")
        for i, chunk in enumerate(retrieved, 1):
            preview = chunk["text"][:120].replace("\n", " ")
            print(f"    [{i}] {chunk['source']} (score={chunk['score']:.4f})")
            print(f"        '{preview}...'")

        sources = sorted(set(c["source"] for c in retrieved))
        print(f"\n  📄 Source docs: {', '.join(sources)}")
        print(f"\n  💬 Answer:\n  {answer}")

        # Collect for markdown output
        chunk_md = ""
        for i, chunk in enumerate(retrieved, 1):
            excerpt = chunk["text"][:200].replace("\n", " ").strip()
            chunk_md += (
                f"\n  **Chunk {i}** — `{chunk['source']}` "
                f"(score: {chunk['score']:.4f})\n"
                f"  > {excerpt}…\n"
            )

        demo_sections.append(
            f"### Q{q_num}: {question}\n\n"
            f"**Retrieved Chunks:**\n{chunk_md}\n"
            f"**Source Documents:** {', '.join(f'`{s}`' for s in sources)}\n\n"
            f"**Answer:**\n{answer}\n"
        )

    # ── Write rag_demo.md ──────────────────────────────────────────
    md_content = f"""# RetailPulse RAG Demo — Pipeline B

## Configuration

| Setting | Value |
|---|---|
| Embedding Model | `{EMBED_MODEL}` |
| Vector Store | FAISS (faiss-cpu, IndexFlatL2) |
| LLM Backend | `{'OpenAI — ' + os.getenv('OPENAI_MODEL','gpt-3.5-turbo') if USE_OPENAI else 'Local — google/flan-t5-base'}` |
| Top-K Retrieval | {TOP_K} |
| Chunk Size | {CHUNK_SIZE} chars |
| Chunk Overlap | {CHUNK_OVERLAP} chars |
| Documents Loaded | {len(docs)} |
| Total Chunks | {len(chunks)} |

---

## Demo Questions & Answers

{chr(10).join(f"---{chr(10)}{section}" for section in demo_sections)}

---

*Generated by RetailPulse AI Customer Intelligence Copilot — Pipeline B (RAG)*
"""

    DEMO_OUT.write_text(md_content, encoding="utf-8")
    print(f"\n\n{'='*65}")
    print(f"  ✅  RAG demo saved → {DEMO_OUT}")
    print(f"{'='*65}\n")


if __name__ == "__main__":
    run_rag_demo()
