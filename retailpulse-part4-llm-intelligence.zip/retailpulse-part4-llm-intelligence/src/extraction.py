"""
extraction.py — Pipeline A: LLM Structured Customer Support Extraction

Strategy:
  - If OPENAI_API_KEY is set in .env → use OpenAI (gpt-3.5-turbo)
  - Otherwise → use local google/flan-t5-base (no API key, no internet needed)

Output: outputs/extraction_results.json
"""

import json
import os
import sys
import re
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

# Load .env if present
load_dotenv()

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))
from src.schema import TicketExtraction, ExtractionResult

# ─────────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────────
ROOT    = Path(__file__).parent.parent
TICKETS = ROOT / "data" / "support_tickets.csv"
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)

RESULT_FILE = OUTPUTS / "extraction_results.json"
ERROR_FILE  = OUTPUTS / "validation_errors.json"

# ─────────────────────────────────────────────────────────────────
# LLM PROMPT
# ─────────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are RetailPulse's expert customer support analyst. 
Your task is to analyze customer support messages and extract structured information.
You MUST respond with ONLY a valid JSON object — no preamble, no explanation, no markdown fences.
"""

def build_user_prompt(message: str) -> str:
    return f"""Analyze the following customer support message and return a JSON object with EXACTLY these fields:

- "category": one of ["DELIVERY", "PAYMENT", "PRODUCT", "ACCOUNT", "REFUND", "OTHER"]
- "urgency": one of ["LOW", "MEDIUM", "HIGH", "CRITICAL"]  
- "sentiment": one of ["POSITIVE", "NEUTRAL", "NEGATIVE"]
- "summary": a concise one-sentence summary of the customer's issue (max 100 words)

Customer message:
\"\"\"
{message}
\"\"\"

Respond with ONLY the JSON object. Example:
{{"category": "DELIVERY", "urgency": "HIGH", "sentiment": "NEGATIVE", "summary": "Customer reports package not delivered after 3 days."}}"""


# ─────────────────────────────────────────────────────────────────
# OPENAI BACKEND
# ─────────────────────────────────────────────────────────────────
def extract_with_openai(message: str) -> dict:
    """Call OpenAI API (requires OPENAI_API_KEY env var)."""
    import openai
    api_key = os.getenv("OPENAI_API_KEY")
    model   = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
    client  = openai.OpenAI(api_key=api_key)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": build_user_prompt(message)},
        ],
        temperature=0,
        max_tokens=200,
        response_format={"type": "json_object"},
    )
    raw = response.choices[0].message.content.strip()
    return json.loads(raw)


# ─────────────────────────────────────────────────────────────────
# LOCAL FLAN-T5 BACKEND  (rule-assisted + model summary)
# ─────────────────────────────────────────────────────────────────
_pipeline = None  # lazy-loaded

def _get_pipeline():
    global _pipeline
    if _pipeline is None:
        from transformers import pipeline as hf_pipeline
        print("  ↳ Loading flan-t5-base (first run may download ~300MB)…")
        _pipeline = hf_pipeline(
            "text2text-generation",
            model="google/flan-t5-base",
            max_new_tokens=120,
        )
    return _pipeline


def _rule_classify_category(msg: str) -> str:
    m = msg.lower()
    if any(w in m for w in ["deliver", "shipment", "shipped", "tracking", "package", "dispatch", "carrier", "late", "arrive"]):
        return "DELIVERY"
    if any(w in m for w in ["refund", "money back", "reimburs", "credit back"]):
        return "REFUND"
    if any(w in m for w in ["pay", "charge", "bill", "invoice", "transaction", "duplicate charge", "debit", "credit card"]):
        return "PAYMENT"
    if any(w in m for w in ["product", "item", "defect", "broken", "damage", "wrong", "counterfeit", "quality"]):
        return "PRODUCT"
    if any(w in m for w in ["account", "login", "password", "sign in", "hack", "access"]):
        return "ACCOUNT"
    return "OTHER"


def _rule_classify_urgency(msg: str) -> str:
    m = msg.lower()
    if any(w in m for w in ["immediately", "urgent", "asap", "right now", "emergency", "hacked", "fraud", "stolen", "critical"]):
        return "CRITICAL"
    if any(w in m for w in ["today", "immediately", "cannot wait", "must", "unacceptable"]):
        return "HIGH"
    if any(w in m for w in ["please", "help", "issue", "problem", "not working"]):
        return "MEDIUM"
    return "LOW"


def _rule_classify_sentiment(msg: str) -> str:
    m = msg.lower()
    if any(w in m for w in ["thank", "great", "excellent", "wonderful", "happy", "pleased", "impressed", "exceeded"]):
        return "POSITIVE"
    if any(w in m for w in ["frustrated", "angry", "terrible", "horrible", "unacceptable", "worst", "ridiculous", "furious", "disgusting"]):
        return "NEGATIVE"
    if any(w in m for w in ["not work", "broken", "wrong", "missing", "didn't", "lost", "stuck", "error", "fail"]):
        return "NEGATIVE"
    return "NEUTRAL"


def _generate_summary_local(message: str) -> str:
    """Use flan-t5 to generate a one-sentence summary."""
    pipe = _get_pipeline()
    prompt = f"Summarize this customer complaint in one sentence: {message}"
    result = pipe(prompt, max_new_tokens=80)[0]["generated_text"].strip()
    # Truncate if too long
    if len(result) > 300:
        result = result[:297] + "..."
    return result if result else "Customer reported an issue requiring support."


def extract_with_local_model(message: str) -> dict:
    """Rule-based classification + T5 summary generation."""
    category  = _rule_classify_category(message)
    urgency   = _rule_classify_urgency(message)
    sentiment = _rule_classify_sentiment(message)
    summary   = _generate_summary_local(message)

    return {
        "category":  category,
        "urgency":   urgency,
        "sentiment": sentiment,
        "summary":   summary,
    }


# ─────────────────────────────────────────────────────────────────
# DISPATCHER
# ─────────────────────────────────────────────────────────────────
USE_OPENAI = bool(os.getenv("OPENAI_API_KEY"))

def extract_ticket(message: str) -> dict:
    if USE_OPENAI:
        return extract_with_openai(message)
    else:
        return extract_with_local_model(message)


# ─────────────────────────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────────────────────────
def run_extraction_pipeline() -> tuple[list, list]:
    """Process all tickets and return (results, errors)."""
    df = pd.read_csv(TICKETS)
    print(f"\n{'='*60}")
    print(f"  Pipeline A — LLM Structured Extraction")
    print(f"  Backend : {'OpenAI (' + os.getenv('OPENAI_MODEL', 'gpt-3.5-turbo') + ')' if USE_OPENAI else 'Local (flan-t5-base + rules)'}")
    print(f"  Tickets : {len(df)}")
    print(f"{'='*60}\n")

    results = []
    errors  = []

    for _, row in df.iterrows():
        tid = row["ticket_id"]
        msg = row["message"]
        print(f"  Processing {tid}…", end=" ")

        try:
            raw_data = extract_ticket(msg)
            extracted = TicketExtraction(**raw_data)

            result = ExtractionResult(
                ticket_id=tid,
                message=msg,
                extracted=extracted,
                status="success",
            )
            results.append(result.model_dump())
            print(f"✅  {extracted.category.value} / {extracted.urgency.value} / {extracted.sentiment.value}")

        except Exception as e:
            err = ExtractionResult(
                ticket_id=tid,
                message=msg,
                error=str(e),
                status="error",
            )
            errors.append(err.model_dump())
            print(f"❌  ERROR: {e}")

    # Save outputs
    with open(RESULT_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)

    with open(ERROR_FILE, "w", encoding="utf-8") as f:
        json.dump(errors, f, indent=2, default=str)

    print(f"\n{'='*60}")
    print(f"  ✅  Saved {len(results)} results → {RESULT_FILE}")
    print(f"  {'⚠️ ' if errors else '✅ '} {len(errors)} errors    → {ERROR_FILE}")
    print(f"{'='*60}\n")

    return results, errors


if __name__ == "__main__":
    run_extraction_pipeline()
